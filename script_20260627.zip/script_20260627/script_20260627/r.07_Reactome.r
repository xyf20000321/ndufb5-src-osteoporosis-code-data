rm(list = ls())
setwd("/data/nas1/liky/project/FX65_KYGW-170308-1-FG/07_Reactome")
ORIGINAL_DIR <- "/data/nas1/liky/project/FX65_KYGW-170308-1-FG/"
output <- file.path(ORIGINAL_DIR, "07_Reactome")

library(Seurat)
library(scMetabolism)
library(ggplot2)
library(pheatmap)
library(dplyr)
library(RColorBrewer)
library(grid)

seu_mono <- readRDS('/data/nas1/zhangyusheng_OD/project/03_project_job099/04_singlecell/seu_mono.rds')
# ↑ 路径改成你实际保存 seu_mono.rds 的位置

seu_mono[["RNA"]] <- as(seu_mono[["RNA"]], "Assay")

seu_mono_kegg <- sc.metabolism.Seurat(
  obj = seu_mono,
  method = "AUCell",
  imputation = FALSE,
  ncores = 8,
  metabolism.type = "KEGG"
)
saveRDS(seu_mono_kegg, 'seu_mono_kegg_metabolism.rds')

seu_mono_reactome <- sc.metabolism.Seurat(
  obj = seu_mono,
  method = "AUCell",
  imputation = FALSE,
  ncores = 8,
  metabolism.type = "REACTOME"
)
saveRDS(seu_mono_reactome, 'seu_mono_reactome_metabolism.rds')

kegg_score     <- seu_mono_kegg@assays$METABOLISM$score
reactome_score <- seu_mono_reactome@assays$METABOLISM$score

plot_metabolism_heatmap_zscore <- function(score_matrix, meta_data, group_col,
                                           top_n = 10, title = "Metabolic Pathway Activity",
                                           filename_prefix = "heatmap") {
  groups <- meta_data[[group_col]]
  unique_groups <- unique(groups)
  
  avg_score <- sapply(unique_groups, function(g) {
    cells <- which(groups == g)
    rowMeans(score_matrix[, cells, drop = FALSE])
  })
  colnames(avg_score) <- unique_groups
  
  pathway_var  <- apply(avg_score, 1, var)
  top_pathways <- names(sort(pathway_var, decreasing = TRUE))[1:min(top_n, nrow(avg_score))]
  avg_score_top <- avg_score[top_pathways, ]
  
  avg_score_scaled <- t(scale(t(avg_score_top)))
  avg_score_scaled[is.nan(avg_score_scaled)] <- 0
  
  p <- pheatmap(
    avg_score_scaled,
    color = colorRampPalette(rev(brewer.pal(11, "RdBu")))(100),
    clustering_method = "ward.D2",
    cluster_cols = TRUE,
    show_rownames = TRUE,
    show_colnames = TRUE,
    fontsize_row = 14,
    fontsize_col = 14,
    border_color = NA,
    main = title,
    angle_col = 45,
    silent = TRUE
  )
  
  pdf(paste0(filename_prefix, '.pdf'), width = 10, height = 14, family = 'serif')
  grid.newpage(); grid.draw(p$gtable)
  dev.off()
  
  png(paste0(filename_prefix, '.png'), width = 10, height = 14,
      units = 'in', res = 300, family = 'serif')
  grid.newpage(); grid.draw(p$gtable)
  dev.off()
  
  return(avg_score_scaled)
}

kegg_heatmap_cluster <- plot_metabolism_heatmap_zscore(
  score_matrix = kegg_score,
  meta_data    = seu_mono_kegg@meta.data,
  group_col    = "seurat_clusters",
  top_n        = 10,
  title        = "Monocyte KEGG Metabolic Pathway Activity (OP)",
  filename_prefix = "Mono_KEGG_heatmap_cluster"
)

reactome_heatmap_cluster <- plot_metabolism_heatmap_zscore(
  score_matrix = reactome_score,
  meta_data    = seu_mono_reactome@meta.data,
  group_col    = "seurat_clusters",
  top_n        = 10,
  title        = "Monocyte REACTOME Metabolic Pathway Activity (OP)",
  filename_prefix = "Mono_REACTOME_heatmap_cluster"
)
