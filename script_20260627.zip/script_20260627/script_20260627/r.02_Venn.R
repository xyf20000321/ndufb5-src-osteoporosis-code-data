rm(list = ls())
setwd('')
ORIGINAL_DIR <- ""
output <- file.path(ORIGINAL_DIR, "02_Venn")

library(msigdbr)
library(dplyr)
library(ggvenn)
library(readr)

all_msigdb <- msigdbr(species = "Homo sapiens")

target_pathways <- c(
  "BIOCARTA_IL10_PATHWAY", "BIOCARTA_IL17_PATHWAY", 
  "GOBP_REGULATION_OF_NEUROINFLAMMATORY_RESPONSE", 
  "GOBP_L_KYNURENINE_METABOLIC_PROCESS", "HP_WRITER_S_CRAMP", 
  "WP_PURINERGIC_SIGNALING", "GOBP_FOREBRAIN_DEVELOPMENT", 
  "WP_MITOCHONDRIAL_COMPLEX_I_ASSEMBLY_MODEL_OXPHOS_SYSTEM", 
  "GOBP_NEUROENDOCRINE_CELL_DIFFERENTIATION", 
  "SU_HO_CONV_CENT_CHONDROSARCOMA_LEUKOCYTE_C0_M1_MACROPHAGE", 
  "GOBP_REGULATION_OF_NEURON_DIFFERENTIATION", 
  "GOBP_REGULATION_OF_MICROGLIAL_CELL_ACTIVATION", 
  "WP_SYNAPTIC_VESICLE_PATHWAY", "ST_PHOSPHOINOSITIDE_3_KINASE_PATHWAY", 
  "GOBP_POSITIVE_REGULATION_OF_NEUROEPITHELIAL_CELL_DIFFERENTIATION"
)

neuro_immune_genes <- all_msigdb %>%
  dplyr::filter(gs_name %in% target_pathways) %>%
  distinct(gene_symbol) %>% 
  pull(gene_symbol)

write.csv(data.frame(gene_symbol = neuro_immune_genes),
          file = "neuro_immune_genes.csv",
          row.names = FALSE,
          quote = FALSE)
neuro_immune_genes <- read.csv('neuro_immune_genes.csv')$gene_symbol
sig_res <- read.csv('')
sig_genes <- unique(sig_res$gene) 
common_genes <- base::intersect(sig_genes, neuro_immune_genes) 
sig_only <- base::setdiff(sig_genes, neuro_immune_genes)
neuro_only <- base::setdiff(neuro_immune_genes, sig_genes)
df <- data.frame(Gene_Symbol = common_genes)
df$Gene_Symbol
write.csv(df, 
          "intersect.csv", 
          row.names = FALSE)
venn_list <- list(
  "Neuro-Immune Genes" = neuro_immune_genes, 
  "Significant DEGs" = sig_genes
)
p <- ggvenn(
  venn_list, 
  fill_color = c("#FFB6C1", "#87CEFA"), 
  stroke_size = 0.5, set_name_size = 4
)
ggsave(filename = paste0(output,"/Venn_sigres_Neuro.pdf"), plot = p, width = 6, height = 5)
ggsave(filename = paste0(output,"/Venn_sigres_Neuro.png"), plot = p, width = 6, height = 5, dpi = 300)

library(readr)
library(dplyr)    
library(ggvenn)   

dat <- as.data.frame(read_csv("",
                              skip = 1,
                              show_col_types = FALSE))
MCC_symbols <- unique(dat[[2]])     

dat2 <- as.data.frame(read_csv("",
                               skip = 1,
                               show_col_types = FALSE))
Degree_symbols <- unique(dat2[[2]]) 
venn_list <- list(
  MCC   = MCC_symbols,
  Degree = Degree_symbols
)

p <- ggvenn(
  venn_list,
  fill_color = c("#FFB6C1", "#87CEFA"),
  stroke_size = 0.5,
  set_name_size = 4,
  show_percentage = TRUE,          
  show_elements = FALSE              
)
ggsave(filename = paste0(output, "/Venn_MCC_Degree.pdf"), plot = p, width = 6, height = 5)
ggsave(filename = paste0(output, "/Venn_MCC_Degree.png"), plot = p, width = 6, height = 5, dpi = 300)
intersection <- intersect(MCC_symbols, Degree_symbols)
write.csv(intersection, 
          "cytoscape.csv", 
          row.names = FALSE)

library(clusterProfiler)
library(org.Hs.eg.db)
library(ggplot2)
library(enrichplot)
library(dplyr)

genes <- read.csv("")
gene_symbols <- as.character(genes$x)
gene_entrez <- bitr(gene_symbols, fromType="SYMBOL", toType="ENTREZID", OrgDb=org.Hs.eg.db)

go_bp <- enrichGO(gene=gene_entrez$ENTREZID, OrgDb=org.Hs.eg.db,
                  ont="BP", pAdjustMethod="BH",
                  pvalueCutoff=0.05, qvalueCutoff=0.2, readable=TRUE)

go_cc <- enrichGO(gene=gene_entrez$ENTREZID, OrgDb=org.Hs.eg.db,
                  ont="CC", pAdjustMethod="BH",
                  pvalueCutoff=0.05, qvalueCutoff=0.2, readable=TRUE)

go_mf <- enrichGO(gene=gene_entrez$ENTREZID, OrgDb=org.Hs.eg.db,
                  ont="MF", pAdjustMethod="BH",
                  pvalueCutoff=0.05, qvalueCutoff=0.2, readable=TRUE)

write.csv(as.data.frame(go_bp), file.path(output, "GO_BP_results.csv"), row.names=FALSE)
write.csv(as.data.frame(go_cc), file.path(output, "GO_CC_results.csv"), row.names=FALSE)
write.csv(as.data.frame(go_mf), file.path(output, "GO_MF_results.csv"), row.names=FALSE)

kegg <- enrichKEGG(gene=gene_entrez$ENTREZID, organism="hsa",
                   pAdjustMethod="BH", pvalueCutoff=0.05, qvalueCutoff=0.2)
kegg <- setReadable(kegg, OrgDb=org.Hs.eg.db, keyType="ENTREZID")
write.csv(as.data.frame(kegg), file.path(output, "KEGG_results.csv"), row.names=FALSE)
go_all <- rbind(
  as.data.frame(go_bp) %>% mutate(Ontology="BP"),
  as.data.frame(go_cc) %>% mutate(Ontology="CC"),
  as.data.frame(go_mf) %>% mutate(Ontology="MF")
) %>% filter(p.adjust < 0.05) %>%
  arrange(Ontology, p.adjust) %>%
  group_by(Ontology) %>%
  dplyr::slice(1:10) %>%
  ungroup() %>%
  mutate(Description=factor(Description, levels=rev(unique(Description))))

p_go <- ggplot(go_all, aes(x=GeneRatio, y=Description, size=Count, color=p.adjust)) +
  geom_point() +
  scale_color_gradient(low="#B72230", high="#104680") +
  scale_size_continuous(range=c(3,8)) +
  facet_wrap(~Ontology, scales="free_y", ncol=1) +
  theme_bw(base_size=12) +
  theme(
    axis.text.y=element_text(size=10),
    strip.text=element_text(face="bold", size=11),
    strip.background=element_rect(fill="grey95"),
    panel.grid.minor=element_blank(),
    legend.position="right"
  ) +
  labs(x="Gene Ratio", y="", color="p.adjust", size="Count",
       title="GO Enrichment Analysis")

ggsave(file.path(output, "01.GO_bubble.pdf"), p_go, width=10, height=14)
ggsave(file.path(output, "01.GO_bubble.png"), p_go, width=10, height=14, dpi=300)

kegg_df <- as.data.frame(kegg) %>%
  filter(p.adjust < 0.05) %>%
  arrange(p.adjust) %>%
  dplyr::slice(1:20) %>%
  mutate(Description=factor(Description, levels=rev(unique(Description))))

p_kegg <- ggplot(kegg_df, aes(x=GeneRatio, y=Description, size=Count, color=p.adjust)) +
  geom_point() +
  scale_color_gradient(low="#B72230", high="#104680") +
  scale_size_continuous(range=c(3,8)) +
  theme_bw(base_size=12) +
  theme(
    axis.text.y=element_text(size=10),
    panel.grid.minor=element_blank(),
    legend.position="right"
  ) +
  labs(x="Gene Ratio", y="", color="p.adjust", size="Count",
       title="KEGG Enrichment Analysis")

ggsave(file.path(output, "02.KEGG_bubble.pdf"), p_kegg, width=10, height=8)
ggsave(file.path(output, "02.KEGG_bubble.png"), p_kegg, width=10, height=8, dpi=300)
