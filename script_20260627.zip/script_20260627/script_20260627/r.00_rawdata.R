rm(list = ls())
setwd('')
ORIGINAL_DIR <- ""
output <- file.path(ORIGINAL_DIR, "00_rawdata")

library(GEOquery)
library(tidyverse)
library(lance)
library(org.Hs.eg.db)
library(dplyr)
library(oligo)
library(AnnotationDbi)
library(stringr)
library(biomaRt)
library(data.table)

gset <- getGEO(
  filename = "GSE56815_series_matrix.txt.gz",  
  destdir = ".", 
  AnnotGPL = F, 
  getGPL = F
)
expr <- Biobase::exprs(gset)
qx <- as.numeric(quantile(expr, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
LogC <- (qx[5] > 100) || (qx[6]-qx[1] > 50 && qx[2] > 0) || (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
if (LogC) {
  expr[which(expr <= 0)] <- 0
  expr <- log2(expr + 1)
  print("log2 transform finished")
} else {
  print("log2 transform not needed")
}

expr <- as.data.frame(expr)
expr <- na.omit(expr)

gpl <- read.table('GPL96-57554.txt', header=TRUE, fill=T, sep='\t', comment.char='#', stringsAsFactors=FALSE, quote='')
ids <- gpl[,c('ID','Gene.Symbol')]
ids$ID <- trimws(as.character(ids$ID))
ids$symbol <- trimws(str_split(ids$Gene.Symbol, '///', simplify = T)[,1])
ids <- ids[ids$symbol != '',]
ids <- ids[ids$ID %in% rownames(expr),]
ids$ID <- as.character(ids$ID)
exp2 <- expr[ids$ID,]
in_check <- rownames(exp2) %in% ids$ID
table(in_check)

exp3 <- cbind(ids,exp2)      
rownames(exp3)<-exp3[,1];exp3<-exp3[,-c(1,2)]
exp3$rowMean <- rowMeans(exp3[, grep("GSM", colnames(exp3))])
exp3 <- exp3[order(-exp3$rowMean), ]
exp3 <- exp3[!duplicated(exp3$symbol), ]
exp3$rowMean <- NULL  
rownames(exp3) <- exp3$symbol  
exp3 <- exp3[, -c(1)]
gset_list <- getGEO("GSE56815", destdir = ".", getGPL = F)
pd <- pData(gset_list[[1]])
write.csv(pd, 'pd.csv')
colnames(pd)
clin_core <- pd[, c("geo_accession", 
                    "gender:ch1",
                    "state:ch1",
                    "bone mineral density:ch1")]
colnames(clin_core) <- c("sample_id", "gender", "menopause_state", "BMD_status")
clin_core$group <- ifelse(clin_core$BMD_status == "low BMD", "OP",
                          ifelse(clin_core$BMD_status == "high BMD", "control", "delete"))
clin_core <- clin_core[clin_core$group != "delete", ]
clin_core$group <- factor(clin_core$group, levels = c("control", "OP"))
common_samples <- base::intersect(colnames(exp3), clin_core$sample_id)

exp_filtered <- exp3[, common_samples]
clin_filtered <- clin_core[match(common_samples, clin_core$sample_id), ]

group <- data.frame(
  sample = clin_filtered$sample_id,
  group = clin_filtered$group
)
GEO_data <- "GSE56815"
write.csv(exp_filtered, file = paste0("dat.", GEO_data, ".csv"))
write.csv(group, file = paste0("group.", GEO_data, ".csv"), row.names = FALSE)
print(table(group$group))

rm(list = ls())
setwd('')
ORIGINAL_DIR <- ""
output <- file.path(ORIGINAL_DIR, "00_rawdata")

library(GEOquery)
library(tidyverse)
library(stringr)
gset <- getGEO(
  filename = "GSE7429_series_matrix.txt.gz",  
  destdir = ".", 
  AnnotGPL = F, 
  getGPL = F
)
expr <- Biobase::exprs(gset)
qx <- as.numeric(quantile(expr, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
LogC <- (qx[5] > 100) ||
  (qx[6]-qx[1] > 50 && qx[2] > 0) ||
  (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
if (LogC) {
  expr[which(expr <= 0)] <- 0
  expr <- log2(expr + 1)
  print("log2 transform finished")
} else {
  print("log2 transform not needed")
}
expr <- as.data.frame(expr)
expr <- na.omit(expr)
gpl <- read.table('GPL96-57554.txt', header=TRUE, fill=T, sep='\t', 
                  comment.char='#', stringsAsFactors=FALSE, quote='') 
ids <- gpl[,c('ID','Gene.Symbol')]
ids$ID <- trimws(as.character(ids$ID))
ids$symbol <- trimws(str_split(ids$Gene.Symbol, '///', simplify = T)[,1])
ids <- ids[ids$symbol != '', ]
ids <- ids[ids$ID %in% rownames(expr), ]
ids$ID <- as.character(ids$ID)
exp2 <- expr[as.character(ids$ID), ]
exp3 <- cbind(symbol = ids$symbol, exp2) 
exp3 <- exp3 %>% dplyr::filter(!is.na(symbol) & symbol != "")
exp3$rowMean <- rowMeans(exp3[, -1]) 
exp3 <- exp3[order(exp3$symbol, -exp3$rowMean), ] 
exp3 <- exp3[!duplicated(exp3$symbol), ] 
rownames(exp3) <- exp3$symbol
exp3 <- exp3[, !colnames(exp3) %in% c("symbol", "rowMean")]
pd <- pData(gset)
colnames(pd)
table(pd$title)

clin_core <- pd[, c(
  "geo_accession",
  "title"
)]
clin_core$group <- ifelse(
  grepl("lowBMD", clin_core$title, ignore.case = TRUE),
  "OP",
  "control"
)
clin_core$group <- factor(clin_core$group, levels = c("control", "OP"))
common_samples <- base::intersect(colnames(exp3), clin_core$geo_accession)
exp_filtered <- exp3[, common_samples]
clin_filtered <- clin_core[match(common_samples, clin_core$geo_accession), ]
group <- data.frame(
  sample = clin_filtered$geo_accession,
  group = clin_filtered$group
)
GEO_data <- "GSE7429"
write.csv(exp_filtered, file = paste0("dat.", GEO_data, ".csv"))
write.csv(group, file = paste0("group.", GEO_data, ".csv"), row.names = FALSE)
print(table(group$group))

rm(list = ls())
setwd('')
ORIGINAL_DIR <- ""
output <- file.path(ORIGINAL_DIR, "00_rawdata")

library(GEOquery)
library(tidyverse)
library(stringr)
gset <- getGEO(
  filename = "GSE13850_series_matrix.txt.gz",  
  destdir = ".", 
  AnnotGPL = F, 
  getGPL = F
)
expr <- Biobase::exprs(gset)
qx <- as.numeric(quantile(expr, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
LogC <- (qx[5] > 100) ||
  (qx[6]-qx[1] > 50 && qx[2] > 0) ||
  (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
if (LogC) {
  expr[which(expr <= 0)] <- 0
  expr <- log2(expr + 1)
  print("log2 transform finished")
} else {
  print("log2 transform not needed")
}
expr <- as.data.frame(expr)
expr <- na.omit(expr)
gpl <- read.table('GPL96-57554.txt', header=TRUE, fill=T, sep='\t', 
                  comment.char='#', stringsAsFactors=FALSE, quote='') 
ids <- gpl[,c('ID','Gene.Symbol')]
ids$ID <- trimws(as.character(ids$ID))
ids$symbol <- trimws(str_split(ids$Gene.Symbol, '///', simplify = T)[,1])
ids <- ids[ids$symbol != '', ]
ids <- ids[ids$ID %in% rownames(expr), ]
ids$ID <- as.character(ids$ID)
exp2 <- expr[as.character(ids$ID), ]
exp3 <- cbind(symbol = ids$symbol, exp2) 
exp3 <- exp3 %>% dplyr::filter(!is.na(symbol) & symbol != "")
exp3$rowMean <- rowMeans(exp3[, -1]) 
exp3 <- exp3[order(exp3$symbol, -exp3$rowMean), ] 
exp3 <- exp3[!duplicated(exp3$symbol), ] 
rownames(exp3) <- exp3$symbol
exp3 <- exp3[, !colnames(exp3) %in% c("symbol", "rowMean")]
pd <- pData(gset)
colnames(pd)
table(pd$title)

clin_core <- pd[, c("geo_accession", "title")]
clin_core <- clin_core[!grepl("Smoking|smoking", clin_core$title, ignore.case = TRUE), ]
clin_core$group <- ifelse(
  grepl("lowBMD|low BMD", clin_core$title, ignore.case = TRUE),
  "OP",
  ifelse(
    grepl("highBMD|high BMD", clin_core$title, ignore.case = TRUE),
    "control",
  )
)
clin_core <- clin_core[!is.na(clin_core$group), ]

clin_core$group <- factor(clin_core$group, levels = c("control", "OP"))
common_samples <- base::intersect(colnames(exp3), clin_core$geo_accession)
exp_filtered <- exp3[, common_samples, drop = FALSE]
clin_filtered <- clin_core[match(common_samples, clin_core$geo_accession), ]
group <- data.frame(
  sample = clin_filtered$geo_accession,
  group = clin_filtered$group
)
GEO_data <- "GSE13850"
write.csv(exp_filtered, file = paste0("dat.", GEO_data, ".csv"), row.names = TRUE)
write.csv(group, file = paste0("group.", GEO_data, ".csv"), row.names = FALSE)
