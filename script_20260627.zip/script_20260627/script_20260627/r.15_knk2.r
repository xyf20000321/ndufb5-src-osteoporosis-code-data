rm(list = ls())
setwd('/data/nas1/liky/project/FX65_KYGW-170308-1-FG/15_knk2')
ORIGINAL_DIR <- "/data/nas1/liky/project/FX65_KYGW-170308-1-FG/"
output <- file.path(ORIGINAL_DIR, "/15_knk2")


library(dplyr)
library(Seurat)
library(scTenifoldKnk)
library(ggplot2)
library(ggrepel) 


# nohup Rscript /data/nas1/chenyongzhi/Research/07-scTenifoldKnk/scTenifoldKnk.R > log.txt 2>&1 &

UMAP <- readRDS("/data/nas1/zhangyusheng_OD/project/03_project_job099/04_singlecell/UMAP.rds")


scRNA_harmony=UMAP
table(Idents(scRNA_harmony))
table(Idents(scRNA_harmony))



scRNA_harmony <- FindVariableFeatures(
  scRNA_harmony,
  selection.method = "vst",
  nfeatures = 2000
)

hvg <- VariableFeatures(scRNA_harmony)




# 2. 强制加入 KO gene
ko_gene1 <- "NDUFB5"
# ko_gene1 <- "SRC"
genes_use1 <- unique(c(hvg, ko_gene1))


# 提取count矩阵作为输入
countMatrix1 <- GetAssayData(
  scRNA_harmony,
  layer = "counts"
)[genes_use1, ]


# countMatrix1 <- GetAssayData(
#   scRNA_harmony,
#   layer = "counts"   
# )



ko_gene1 %in% rownames(countMatrix1)

# 执行敲除分析（推荐用高变基因做）：
# 参数gKO用于指定敲除的基因；qc开头的系列参数能够选择是否对矩阵进行质控以及相应指标；nc开头的参数对应网络的构建，
# 分别包括子网络的数量、使用的PC数量、随机抽取的细胞数量，数值越大运行时间越长但是结果可能会更稳定



#############基因敲除加速#####################


# 1.主要修改：将scTenifoldKnk函数改为了scTenifoldNet.lite::scTenifoldKnk
# 2.fast = TRUE


# 原理
# 
# 细胞抽样：随机抽取nCells个细胞（默认500），抽nNet次（默认10次）。分别用这10个抽样的表达矩阵，
# 按照下面的方法计算基因调控网络（GRN）。
# 
# 主成分回归（Principle Component Regression，PCR），对每个基因计算其受其他基因调控的回归方程，
# 其系数即可作为调控网络的系数。合并所有系数即可得到GRN。
# 
# 原版软件PCR过程中对每个基因都做了一次奇异值分解（Singular value decomposition，SVD），
# 如果有10000个基因，就要重复计算10000次，非常耗时。我在极速模式中改成了对所有基因一次性计算全局SVD
# ，直接让计算次数减少几千倍。
# 
# 降噪：对10次抽样得到的GRN合并成一个基因x基因x抽样次数的三维张量，
# 进行张量分解（CANDECOMP/PARAFAC tensor decomposition），得到降噪后的GRN，即WT的调控网络。
# 
# 在WT网络中把需要敲除的基因入度设为0，即可模拟敲除效应，得到KO网络。
# 
# 将WT网络和KO网络进行非线性降维，为网络中的每个基因对齐低维空间坐标。
# 原版算法在这里构建了一个2N * 2N大小的矩阵，非常占用内存！我借助RSpectra::svds的优化算法解决了这个问题。
# 
# 在低维空间中，计算每个基因在两个网络之间的欧氏距离，作为敲除事件的扰动效应。

############################################


# result <- scTenifoldNet.lite::scTenifoldKnk(countMatrix1, gKO = 'ACTA2', qc = FALSE, nCores = 8, fast = TRUE)
result <- scTenifoldKnk(countMatrix1, gKO = 'NDUFB5', qc = FALSE, nCores = 8)
# result <- scTenifoldKnk(countMatrix1, gKO = 'SRC', qc = FALSE, nCores = 8)
# 
# # result <- scTenifoldKnk(countMatrix = countMatrix1, 
# #                         gKO = 'ACTA2', #需要敲除的基因
# #                         # qc = TRUE,#是否进行QC
# #                         # qc_mtThreshold = 0.1,#mt阈值
# #                         # qc_minLSize = 1000,#文库阈值(细胞测到的基因总数)
# #                         # qc_minLSize = 10,#文库阈值(细胞测到的基因总数)
# #                         # nc_nNet = 10, #子网络数量
# #                         # nc_nCells = 500, #每个网络中随机抽取的细胞数
# #                         # nc_nComp = 3 #PCA 的主成分数量
# # )
# 
# 
# 
# scTenifoldKnk_custom <- scTenifoldKnk
# 
# scTenifoldKnk_custom <- function(countMatrix, gKO, nCores = 8) {
#   
#   # 检查目标基因
#   if (!gKO %in% rownames(countMatrix)) {
#     stop(paste("目标基因不存在：", gKO))
#   }
#   
#   # 筛选基因，强制保留目标基因
#   keep_genes <- rowMeans(countMatrix != 0) >= 0.05
#   keep_genes <- keep_genes | rownames(countMatrix) == gKO
#   
#   countMatrix <- countMatrix[keep_genes, , drop = FALSE]
#   
#   cat("筛选后矩阵维度：", dim(countMatrix), "\n")
#   cat("目标基因是否存在：", gKO %in% rownames(countMatrix), "\n")
#   
#   # 构建网络
#   WT <- scTenifoldNet::makeNetworks(
#     X = countMatrix,
#     q = 0.9,
#     nNet = 10,
#     nCells = 500,
#     scaleScores = TRUE,
#     symmetric = FALSE,
#     nComp = 3,
#     nCores = nCores
#   )
#   
#   # 检查每个网络是否包含目标基因
#   print(lapply(WT, function(x) {
#     c(
#       in_rows = gKO %in% rownames(x),
#       in_cols = gKO %in% colnames(x)
#     )
#   }))
#   
#   # 张量分解
#   WT <- scTenifoldNet::tensorDecomposition(
#     xList = WT,
#     K = 3,
#     maxError = 1e-5,
#     maxIter = 1000,
#     nDecimal = 3
#   )
#   
#   WT <- as.matrix(WT$X)
#   
#   # 检查目标基因
#   if (!gKO %in% rownames(WT) || !gKO %in% colnames(WT)) {
#     stop(paste(
#       "目标基因在网络构建或张量分解后丢失：", gKO
#     ))
#   }
#   
#   # 方向处理
#   WT <- scTenifoldKnk:::strictDirection(WT, lambda = 0)
#   WT <- as.matrix(WT)
#   diag(WT) <- 0
#   WT <- t(WT)
#   
#   # 模拟敲除
#   KO <- WT
#   KO[gKO, ] <- 0
#   
#   # 流形对齐
#   MA <- scTenifoldKnk:::manifoldAlignment(
#     WT,
#     KO,
#     d = 2,
#     nCores = nCores
#   )
#   
#   # 差异调控
#   DR <- dRegulation(MA, gKO)
#   
#   # 输出结果
#   list(
#     tensorNetworks = list(
#       WT = Matrix::Matrix(WT),
#       KO = Matrix::Matrix(KO)
#     ),
#     manifoldAlignment = MA,
#     diffRegulation = DR
#   )
# }
# 
# 
# 
# 
# 
# result_SRC <- scTenifoldKnk_custom(
#   countMatrix = countMatrix1,
#   gKO = "SRC",
#   # qc = FALSE,
#   nCores = 8
# )
# 
# 
# 
# 
# 
# # 检查当前矩阵
# cat("SRC 是否存在：", "SRC" %in% rownames(countMatrix1), "\n")
# 
# # 模糊查找 SRC
# print(rownames(countMatrix1)[
#   grepl("SRC", rownames(countMatrix1), ignore.case = TRUE)
# ])
# 
# # 检查原始 Seurat 对象
# cat(
#   "SRC 是否存在于 Seurat 对象：",
#   "SRC" %in% rownames(scRNA_harmony[["RNA"]]),
#   "\n"
# )
# 
# # 检查原始 counts 矩阵
# countMatrix_raw <- GetAssayData(
#   scRNA_harmony,
#   assay = "RNA",
#   layer = "counts"
# )
# 
# cat(
#   "SRC 是否存在于原始 counts：",
#   "SRC" %in% rownames(countMatrix_raw),
#   "\n"
# )
# 
# 
# 
# hvg <- VariableFeatures(scRNA_harmony)
# 
# genes_use1 <- unique(c(hvg, "SRC"))
# 
# countMatrix1 <- GetAssayData(
#   scRNA_harmony,
#   assay = "RNA",
#   layer = "counts"
# )[genes_use1, , drop = FALSE]
# 
# cat("SRC 是否存在：", "SRC" %in% rownames(countMatrix1), "\n")
# cat("矩阵维度：", dim(countMatrix1), "\n")
# cat("SRC 表达细胞数：", sum(countMatrix1["SRC", ] > 0), "\n")
# 
# 
# # 1. 查看 scTenifoldKnk 的函数参数
# print(formals(scTenifoldKnk))
# 
# # 2. 查看原始函数体
# print(body(scTenifoldKnk))
# 
# # 3. 查看 makeNetworks 的函数定义
# print(scTenifoldNet::makeNetworks)
# 
# # 4. 查看输入矩阵中 SRC 的情况
# cat("SRC存在：", "SRC" %in% rownames(countMatrix1), "\n")
# cat("SRC表达细胞数：", sum(countMatrix1["SRC", ] > 0), "\n")
# cat("输入矩阵维度：", dim(countMatrix1), "\n")
# 
# 
# 




saveRDS(result, file = "scTenifoldKnk_NDUFB5.rds")
# saveRDS(result, file = "scTenifoldKnk_SRC.rds")
#绘图
library(ggplot2)

run_top10_fc <- function(gene, save_type = c("png", "pdf")) {
  
  save_type <- match.arg(save_type)
  
  cat("\n===== Processing gene:", gene, "=====\n")
  
  result <- readRDS(paste0("scTenifoldKnk_", gene, ".rds"))
  diff_reg <- result$diffRegulation
  
  cat("dim:", dim(diff_reg[order(-diff_reg$FC), ]), "\n")
  
  diff_reg$log2FC    <- log2(diff_reg$FC)
  diff_reg$abslog2FC <- abs(diff_reg$log2FC)
  
  diff_reg_sig <- diff_reg %>% filter(p.value < 0.05) %>% filter(gene != !!gene)
  
  if (nrow(diff_reg_sig) == 0) {
    cat("警告：无显著基因（p < 0.05），跳过绘图\n")
    return(invisible(NULL))
  }
  
  sorted_by_abs <- diff_reg_sig[order(-diff_reg_sig$abslog2FC), ]
  
  top10_absolute <- head(sorted_by_abs, 10)
  print(top10_absolute[, c("gene", "log2FC", "p.value")])
  
  write.csv(
    diff_reg$gene,
    file = paste0(gene, "_all_genes.csv"),
    row.names = FALSE,
    quote = FALSE
  )
  write.csv(
    diff_reg_sig[order(-diff_reg_sig$abslog2FC), c("gene", "FC", "log2FC", "p.value")],
    file = paste0(gene, "_sig_genes_p05.csv"),
    row.names = FALSE,
    quote = FALSE
  )
  top_genes <- head(sorted_by_abs, 10)
  
  p <- ggplot(top_genes, aes(x = reorder(gene, log2FC), y = log2FC)) +
    geom_bar(aes(fill = log2FC), stat = "identity") +
    scale_fill_viridis_c() +
    coord_flip() +
    labs(
      title = paste0("Top 10 Differentially Regulated Genes (", gene, ")"),
      x = "Gene",
      y = "log2(Fold Change)"
    ) +
    theme_classic(base_size = 16) +
    theme(
      axis.title = element_text(face = "bold"),
      legend.position = "none"
    )
  
  print(p)
  
  if (save_type == "png") {
    png(
      filename = paste0(gene, "_Top_10_FC_Genes.png"),
      width = 8,
      height = 6,
      units = "in",
      res = 300,
      family = "Times"
    )
    print(p)
    dev.off()
  }
  
  if (save_type == "pdf") {
    pdf(
      file = paste0(gene, "_Top_10_FC_Genes.pdf"),
      width = 8,
      height = 6,
      family = "Times"
    )
    print(p)
    dev.off()
  }
}
run_top10_fc("NDUFB5", save_type = "png")
run_top10_fc("NDUFB5", save_type = "pdf")
# run_top10_fc("SRC", save_type = "png")
# run_top10_fc("SRC", save_type = "pdf")

###热图
library(ggplot2)
library(ggrepel)
library(dplyr)

run_volcano_zscore <- function(gene, label_n = 5, y_limit = 10, x_limit = 4) {
  
  cat("\n===== Volcano plot for:", gene, "=====\n")
  
  result <- readRDS(paste0("scTenifoldKnk_", gene, ".rds"))
  diff_reg <- result$diffRegulation
  
  if ("Z" %in% colnames(diff_reg)) {
    diff_reg$Zscore <- diff_reg$Z
  } else if ("z.score" %in% colnames(diff_reg)) {
    diff_reg$Zscore <- diff_reg$z.score
  } else {
    diff_reg$log2FC <- log2(diff_reg$FC)
    diff_reg$Zscore <- scale(diff_reg$log2FC)[,1]
  }
  
  diff_reg$log10P <- -log10(diff_reg$p.value)
  
  # 右侧：Z>0 且 p值有限的前label_n个
  top_pos <- diff_reg %>%
    filter(Zscore > 0, is.finite(log10P)) %>%
    arrange(desc(log10P)) %>%
    head(label_n)
  
  # 左侧：Z<0 按绝对Z-score排前label_n个
  top_neg <- diff_reg %>%
    filter(Zscore < 0) %>%
    arrange(Zscore) %>%
    head(label_n)
  
  label_df <- bind_rows(top_pos, top_neg)
  
  p <- ggplot(diff_reg, aes(x = Zscore, y = log10P)) +
    geom_point(color = "black", size = 1.2) +
    geom_vline(xintercept = 0, linetype = "dashed", color = "blue") +
    geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "red") +
    geom_text_repel(
      data = label_df,
      aes(label = gene),
      size = 4,
      max.overlaps = Inf,
      box.padding = 0.5,
      force = 2
    ) +
    coord_cartesian(xlim = c(-x_limit, x_limit), ylim = c(0, y_limit)) +
    labs(
      title = paste0(gene, " knockdown"),
      x = "Z-score",
      y = expression(-log[10](p.value))
    ) +
    theme_classic(base_size = 16)
  
  print(p)
  
  png(filename = paste0(gene, "_Zscore_volcano.png"), width = 7, height = 6,
      units = "in", res = 300, family = "Times")
  print(p)
  dev.off()
  
  pdf(file = paste0(gene, "_Zscore_volcano.pdf"), width = 7, height = 6,
      family = "Times")
  print(p)
  dev.off()
}
run_volcano_zscore("NDUFB5", label_n = 5, y_limit = 10, x_limit = 4)
# run_volcano_zscore("SRC", label_n = 5, y_limit = 10, x_limit = 4)


####GO
library(viridis)

run_GO_bar_top10 <- function(gene, save_type = c("png", "pdf")) {
  save_type <- match.arg(save_type)
  
  cat("\n===== Processing GO enrichment for:", gene, "=====\n")
  
  result <- readRDS(paste0("scTenifoldKnk_", gene, ".rds"))
  diff_reg <- result$diffRegulation
  
  sig_genes <- diff_reg %>%
    filter(p.value < 0.05) %>%
    pull(gene)
  
  cat("Number of significant genes:", length(sig_genes), "\n")
  if(length(sig_genes) == 0){
    cat("No significant genes found for", gene, "\n")
    return(NULL)
  }
  
  entrez_ids <- bitr(sig_genes, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db)
  
  all_ont <- c("BP","CC","MF")
  ego_list <- list()
  
  for(ont in all_ont){
    ego <- enrichGO(
      gene = entrez_ids$ENTREZID,
      OrgDb = org.Hs.eg.db,
      keyType = "ENTREZID",
      ont = ont,
      pAdjustMethod = "BH",
      pvalueCutoff = 0.05,
      qvalueCutoff = 0.2,
      readable = TRUE
    )
    if(!is.null(ego) && nrow(as.data.frame(ego)) > 0){
      df <- as.data.frame(ego) %>%
        arrange(p.adjust) %>%   # 按校正p值排序
        head(10)                # Top10
      df$Ontology <- ont
      ego_list[[ont]] <- df
    }
  }
  
  ego_all <- bind_rows(ego_list)
  cat("Total enriched GO terms (Top10 per Ontology):", nrow(ego_all), "\n")
  print(ego_all[, c("ID","Description","Count","p.adjust","Ontology")])
  
  p <- ggplot(ego_all, aes(x = Count, y = reorder(Description, Count), fill = Ontology)) +
    geom_bar(stat = "identity") +
    scale_fill_viridis(discrete = TRUE, option = "C") +
    labs(
      title = paste0(gene, " GO enrichment Top10 per Ontology"),
      x = "Gene Count",
      y = "GO Term",
      fill = "Ontology"
    ) +
    theme_classic(base_size = 14) +
    theme(
      axis.text.y = element_text(size = 10)
    )
  
  print(p)
  
  if(save_type == "png"){
    png(filename = paste0(gene, "_GO_Top10_bar.png"), width = 10, height = 8, units = "in", res = 300)
    print(p)
    dev.off()
  }
  if(save_type == "pdf"){
    pdf(file = paste0(gene, "_GO_Top10_bar.pdf"), width = 10, height = 8)
    print(p)
    dev.off()
  }
  
  return(ego_all)
}
library(clusterProfiler)
library(org.Hs.eg.db) 
ego_NDUFB5 <- run_GO_bar_top10("NDUFB5", save_type = "png")
ego_NDUFB5_pdf <- run_GO_bar_top10("NDUFB5", save_type = "pdf")
# ego_SRC <- run_GO_bar_top10("SRC", save_type = "png")
# ego_SRC_pdf <- run_GO_bar_top10("SRC", save_type = "pdf")

##KEGG
run_KEGG_bar_top10 <- function(gene, save_type = c("png", "pdf")) {
  save_type <- match.arg(save_type)
  
  cat("\n===== Processing KEGG enrichment for:", gene, "=====\n")
  
  # 读取虚拟敲除结果
  result <- readRDS(paste0("scTenifoldKnk_", gene, ".rds"))
  diff_reg <- result$diffRegulation
  
  # 提取显著差异基因
  sig_genes <- diff_reg %>%
    filter(p.value < 0.05) %>%
    pull(gene)
  
  cat("Number of significant genes:", length(sig_genes), "\n")
  if(length(sig_genes) == 0){
    cat("No significant genes found for", gene, "\n")
    return(NULL)
  }
  
  # SYMBOL -> ENTREZID
  entrez_ids <- bitr(sig_genes, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db)
  if(nrow(entrez_ids) == 0){
    cat("No genes mapped to ENTREZID, stop KEGG enrichment.\n")
    return(NULL)
  }
  
  # KEGG富集分析
  ekegg <- enrichKEGG(
    gene = entrez_ids$ENTREZID,
    organism = "hsa",
    pvalueCutoff = 0.05,
    pAdjustMethod = "BH",
    qvalueCutoff = 0.2
  )
  
  if(is.null(ekegg) || nrow(as.data.frame(ekegg)) == 0){
    cat("No significant KEGG pathways found.\n")
    return(NULL)
  }
  
  ekegg_df <- as.data.frame(ekegg) %>%
    arrange(p.adjust) %>%
    head(10)   # Top10 KEGG条目
  
  cat("Top KEGG pathways:\n")
  print(ekegg_df[, c("ID","Description","Count","p.adjust")])
  
  # 条形图
  p <- ggplot(ekegg_df, aes(x = Count, y = reorder(Description, Count), fill = -log10(p.adjust))) +
    geom_bar(stat = "identity") +
    scale_fill_viridis(option = "C") +
    labs(
      title = paste0(gene, " KEGG enrichment"),
      x = "Gene Count",
      y = "KEGG Pathway",
      fill = "-log10(Adjusted P)"
    ) +
    theme_classic(base_size = 14) +
    theme(axis.text.y = element_text(size = 10))
  
  print(p)
  
  # 保存
  if(save_type == "png"){
    png(filename = paste0(gene, "_KEGG_Top10_bar.png"), width = 10, height = 8, units = "in", res = 300)
    print(p)
    dev.off()
  }
  if(save_type == "pdf"){
    pdf(file = paste0(gene, "_KEGG_Top10_bar.pdf"), width = 10, height = 8)
    print(p)
    dev.off()
  }
  
  return(ekegg_df)
}
kegg_NDUFB5 <- run_KEGG_bar_top10("NDUFB5", save_type = "png")
kegg_NDUFB5_pdf <- run_KEGG_bar_top10("NDUFB5", save_type = "pdf")
# kegg_SRC <- run_KEGG_bar_top10("SRC", save_type = "png")
# kegg_SRC_pdf <- run_KEGG_bar_top10("SRC", save_type = "pdf")





