rm(list = ls())
setwd("/data/nas1/zhangyusheng_OD/project/03_project_job099/03_machine")
ORIGINAL_DIR <- "/data/nas1/zhangyusheng_OD/project/03_project_job099/"
output <- file.path(ORIGINAL_DIR, "03_machine")

library(dplyr)
library(tidyr)
library(glmnet)
library(ggplot2)
library(cowplot)
library(reshape2)

dat <- read.csv("/data/nas1/zhangyusheng_OD/project/03_project_job099/00_rawdata/dat.GSE56815.csv", row.names = 1)
group <- read.csv("/data/nas1/zhangyusheng_OD/project/03_project_job099/00_rawdata/group.GSE56815.csv")

df <- read.csv("/data/nas1/zhangyusheng_OD/project/03_project_job099/02_Venn/cytoscape.csv")
target_genes <- as.character(df$x)
dat_target <- dat[rownames(dat) %in% target_genes, ]
dat_target_t <- as.data.frame(t(dat_target)) %>%
  tibble::rownames_to_column("sample")

lasso_data <- merge(dat_target_t, group, by = "sample")
rownames(lasso_data) <- lasso_data$sample
lasso_data$sample <- NULL
lasso_data <- lasso_data[, c(base::intersect(target_genes, colnames(lasso_data)), "group")]
lasso_data$group <- as.factor(lasso_data$group)
write.csv(lasso_data, "lasso_data_train.csv", row.names = TRUE)
x <- as.matrix(lasso_data[, -ncol(lasso_data)])
y <- lasso_data$group
hub_gene <- c("NDUFB5", "IGF1R", "SRC")
######
for (i in 1:100){
  set.seed(i)
  cvfit <- cv.glmnet(as.matrix(lasso_data[-ncol(lasso_data)]), lasso_data$group,
                     family = "binomial", type.measure = "mse",nfolds = 5,maxit = 1e6)
  coef.min <- coef(cvfit, s = cvfit$lambda.min)
  df.coef <- cbind(gene = rownames(coef.min), coefficient = coef.min[,1]) %>% as.data.frame()
  df.coef <- subset(df.coef, coefficient != 0) %>% as.data.frame
  print(paste(i,nrow(df.coef)-1))
  lasso_gene <- df.coef$gene[-1]
  num <- sum(hub_gene %in% lasso_gene)
  # num1 <- sum(diff_gene %in% lasso_gene)
  # if (num >= 2 & num1==0){
  if (num >= 2){
    print(paste(i,":",length(lasso_gene),':',num))
    print(intersect(hub_gene,lasso_gene))
  }
}
#######
i <- 1
set.seed(i)

cvfit <- cv.glmnet(as.matrix(lasso_data[-ncol(lasso_data)]), lasso_data$group,
                   family = "binomial", type.measure = "mse", nfolds = 5,maxit = 1e6)

coef.min <- coef(cvfit, s = cvfit$lambda.min)
df.coef <- cbind(gene = rownames(coef.min), coefficient = coef.min[,1]) %>% as.data.frame()
df.coef <- subset(df.coef, coefficient != 0 & gene != "(Intercept)") %>% as.data.frame()

cat("种子选出的基因总数：", nrow(df.coef), "\n")
print(df.coef$gene)
write.csv(df.coef, "02.lasso_coefficients.csv", row.names = F)


# 3. 预测阳性概率
library(pROC)
pred_prob <- as.numeric(
  
  predict(cvfit, newx = x, s = "lambda.min", type = "response")
  
)

# 4. ROC 曲线及 AUC、95% CI

roc_obj <- roc(
  
  response = y,
  
  predictor = pred_prob,
  
  levels = levels(y),
  
  direction = "<",
  
  quiet = TRUE
  
)

auc_value <- as.numeric(auc(roc_obj))

auc_ci <- ci.auc(
  
  roc_obj,
  
  conf.level = 0.95,
  
  method = "delong"
  
)

cat("AUC:", round(auc_value, 3), "\n")

cat(
  
  "AUC 95% CI:",
  
  round(auc_ci[1], 3), "-",
  
  round(auc_ci[3], 3), "\n"
  
)

# 5. 根据 Youden 指数确定最佳截断值

best_cutoff <- pROC::coords(
  
  roc_obj,
  
  x = "best",
  
  best.method = "youden",
  
  ret = "threshold",
  
  transpose = FALSE
  
)

best_cutoff <- as.numeric(unlist(best_cutoff)[1])

cat("最佳截断值：", best_cutoff, "\n")

# 6. 计算准确率、敏感度和特异度

pred_class <- factor(
  
  ifelse(pred_prob >= best_cutoff, levels(y)[2], levels(y)[1]),
  
  levels = levels(y)
  
)

conf_mat <- table(
  
  Actual = y,
  
  Predicted = pred_class
  
)

print(conf_mat)

TN <- conf_mat[1, 1]

FP <- conf_mat[1, 2]

FN <- conf_mat[2, 1]

TP <- conf_mat[2, 2]

accuracy <- (TP + TN) / sum(conf_mat)

sensitivity <- TP / (TP + FN)

specificity <- TN / (TN + FP)

cat("Accuracy:", round(accuracy, 3), "\n")

cat("Sensitivity:", round(sensitivity, 3), "\n")

cat("Specificity:", round(specificity, 3), "\n")












# 7. 绘制 ROC 曲线

roc_df <- data.frame(
  
  FPR = 1 - roc_obj$specificities,
  
  TPR = roc_obj$sensitivities
  
)

p <- ggplot(roc_df, aes(x = FPR, y = TPR)) +
  
  geom_line(linewidth = 1, color = "#4981bb") +
  
  geom_abline(
    
    intercept = 0,
    
    slope = 1,
    
    linetype = "dashed",
    
    color = "grey60"
    
  ) +
  
  annotate(
    
    "text",
    
    x = 0.60,
    
    y = 0.20,
    
    hjust = 0,
    
    label = paste0(
      
      "AUC = ", sprintf("%.3f", auc_value),
      
      "\nAUC 95% CI: ", sprintf("%.3f", auc_ci[1]),
      
      "-", sprintf("%.3f", auc_ci[3]),
      
      "\nAccuracy = ", sprintf("%.3f", accuracy),
      
      "\nSensitivity = ", sprintf("%.3f", sensitivity),
      
      "\nSpecificity = ", sprintf("%.3f", specificity)
      
    ),
    
    size = 4
    
  ) +
  
  labs(
    
    title = "LASSO ROC Curve",
    
    x = "1 - Specificity",
    
    y = "Sensitivity"
    
  ) +
  
  coord_equal() +
  
  theme_classic(base_size = 14)

print(p)

ggsave(
  
  "/data/nas1/liky/project/FX65_KYGW-170308-1-FG/03_machine/LASSO_ROC.pdf",
  
  plot = p,
  
  width = 6,
  
  height = 6
  
)

ggsave(
  
  "/data/nas1/liky/project/FX65_KYGW-170308-1-FG/03_machine/LASSO_ROC.png",
  
  plot = p,
  
  width = 6,
  
  height = 6,
  
  dpi = 600
  
)







library(ggplot2)
library(reshape)
library(cowplot)
fit <- glmnet(x_matrix, y_vector, family = "binomial", alpha = 1)
{ res_coef <- coef(fit) 
  tmp <- as.data.frame(as.matrix(res_coef))
  tmp <- tmp[-1,]
  tmp$coef <- row.names(tmp)
  tmp <- reshape::melt(tmp, id = "coef")
  tmp$variable <- as.numeric(gsub("s", "", tmp$variable))
  tmp$coef <- gsub('_','-',tmp$coef)
  tmp$lambda <- fit$lambda[tmp$variable+1]
  
  
  keep_genes_plot <- gsub('_','-',df.coef$gene)
  tmp_filtered <- tmp[tmp$coef %in% keep_genes_plot, ]
  
  
  fit_plot <- ggplot() +
    geom_vline(xintercept = log(cvfit$lambda.min),
               size=0.5, color='grey60', alpha=0.8, linetype=2) +
    
    geom_line(data=tmp_filtered, mapping = aes(log(lambda), value, color = coef), size=0.5) +
    
    annotate("text", x = min(log(tmp$lambda)), y = max(tmp_filtered$value), 
             label = paste0('Optimal lambda: ', round(cvfit$lambda.min, 6)), hjust = 0, family = "Times") +
    annotate("text", x = min(log(tmp$lambda)), y = max(tmp_filtered$value)*0.8, 
             label = paste0('n = ', nrow(df.coef)), hjust = 0, family = "Times") +
    labs(x='Log(lambda)', y='Coefficients', color='') +
    guides(color=guide_legend(nrow = 4)) +
    theme_bw() + # 加上背景框，让图更扎实
    theme(axis.title.y = element_text(size = 18, color = 'black'),
          axis.title.x = element_text(size = 18, color = 'black'),
          axis.text.x = element_text(size = 15, color = 'black'),
          axis.text.y = element_text(size = 15, color = 'black'),
          legend.position = 'bottom', # 图例放下面，否则 20 个基因会挤占绘图区
          panel.grid = element_blank())
  
  # 3. CV 误差图 (沿用你的 xx 结构)
  xx <- data.frame(lambda=cvfit[["lambda"]],
                   cvm=cvfit[["cvm"]],
                   cvsd=cvfit[["cvsd"]],
                   cvup=cvfit[["cvup"]],
                   cvlo=cvfit[["cvlo"]],
                   nozezo=cvfit[["nzero"]])
  xx$ll <- log(xx$lambda)
  
  cv_plot <- ggplot(xx, aes(ll, cvm)) +
    geom_errorbar(aes(x=ll, ymin=cvlo, ymax=cvup),
                  width=0.05, size=0.3, color="grey") +
    geom_vline(xintercept = log(cvfit$lambda.min),
               size=0.5, color='grey60', alpha=0.8, linetype=2) +
    geom_point(size=0.8, color='red') +
    
    annotate("text", x = min(xx$ll), y = max(xx$cvup), 
             label = paste0('n = ', nrow(df.coef)), hjust = 0, family = "Times") +
    labs(x='Log(lambda)', y='Binomial Deviance', color='') +
    theme_bw() +
    theme(axis.title.y = element_text(size = 18, color = 'black'),
          axis.title.x = element_text(size = 18, color = 'black'),
          axis.text.x = element_text(size = 15, color = 'black'),
          axis.text.y = element_text(size = 15, color = 'black'),
          panel.grid = element_blank())
  
  # 4. 合并保存
  p_final <- plot_grid(fit_plot, cv_plot, rel_widths = c(1, 0.8))
  ggsave("01.lasso_plot.pdf", p_final, height=6)
  ggsave("01.lasso_plot.png", p_final, height=6, width=12)
}
#4.2SVM-RFE-----------------------------------------------------------------------
library(caret)
library(dplyr)
library(ggplot2)
library(cowplot)

# 数据准备（保持不变）
svm_data <- lasso_data
svm_data$group <- factor(svm_data$group, levels = c("control", "OP"))
feature_data <- svm_data %>% dplyr::select(where(is.numeric))
hub_gene <- c("NDUFB5", "IGF1R", "SRC")

# 1. 定义加速后的 rfeControl
control <- rfeControl(
  functions     = caretFuncs,
  method        = "cv",
  number        = 5,               
  saveDetails   = TRUE,
  allowParallel = FALSE
)

# 2. 开始刷种子（串行版，速度已大幅优化）
good_seeds <- list()

cat("开始刷种子 (加速模式)，总共 100 个种子...\n\n")

for (i in 1:100) {  # 你可以改回 50 或增加到 200
  
  cat("种子 ", sprintf("%3d", i), " ... ")
  
  set.seed(i)
  
  res <- tryCatch({
    rfe(
      x          = feature_data,
      y          = svm_data$group,
      sizes      = 1:ncol(feature_data),   
      rfeControl = control,
      method     = "svmLinear",
      preProcess = c("center", "scale", "nzv"),
      tuneGrid   = data.frame(C = c(0.1, 1, 10))  
    )
  }, error = function(e) {
    message("出错：", e$message)
    NULL
  })
  
  if (is.null(res)) {
    cat("失败，跳过\n")
    next
  }
  
  selected <- predictors(res)
  inter <- intersect(hub_gene, selected)
  
  cat("选了 ", length(selected), " 个 | hub 交集：", length(inter), " 个\n")
  
  if (length(inter) >= 2) {
    cat(">>> 命中！种子 ", i, " 包含：", paste(inter, collapse = ", "), "\n\n")
    
    good_seeds[[as.character(i)]] <- list(
      seed   = i,
      genes  = selected,
      n      = length(selected),
      hub    = inter
    )
  }
}

########

set.seed(35)   # 刷到的种子
results <- caret::rfe(
  x = feature_data,
  y = svm_data$group,
  sizes = 1:ncol(feature_data),  
  rfeControl = control,
  method = "svmLinear",
  preProcess = c("center", "scale", "nzv"),    
  tuneGrid = data.frame(C = c(0.1, 1, 10))   
)

# 然后看结果
print(results)
length(predictors(results))
svm_gene <- data.frame(symbol = predictors(results))
write.csv(svm_gene, "03.SVM_RFE_gene.csv", row.names = FALSE)





# ============================

# 2. 使用筛选后的基因建立 SVM 模型

# ============================

selected_genes <- svm_gene$symbol

x <- feature_data[, selected_genes, drop = FALSE]

y <- factor(svm_data$group)

stopifnot(nlevels(y) == 2)

# 第一个水平作为阴性组，第二个水平作为阳性组

print(levels(y))

# ============================

# 3. 训练 SVM 模型

# ============================

set.seed(35)

svm_fit <- caret::train(
  x = x,
  y = y,
  method = "svmLinear",
  preProcess = c("center", "scale", "nzv"),
  tuneGrid = data.frame(C = 1),
  trControl = caret::trainControl(
    method = "none",
    classProbs = TRUE
  )
)
# 预测各样本属于阳性组的概率

pred_prob <- predict(
  
  svm_fit,
  
  newdata = x,
  
  type = "prob"
  
)[, levels(y)[2]]

# ============================

# 4. ROC 曲线、AUC 和 95% CI

# ============================

roc_obj <- pROC::roc(
  
  response = y,
  
  predictor = pred_prob,
  
  levels = levels(y),
  
  direction = "<",
  
  quiet = TRUE
  
)

auc_value <- as.numeric(pROC::auc(roc_obj))

auc_ci <- pROC::ci.auc(
  
  roc_obj,
  
  conf.level = 0.95,
  
  method = "delong"
  
)

cat("\n========== SVM-RFE 模型评价 ==========\n")

cat("AUC:", round(auc_value, 3), "\n")

cat(
  
  "AUC 95% CI:",
  
  round(auc_ci[1], 3), "-",
  
  round(auc_ci[3], 3), "\n"
  
)

# ============================

# 5. 通过 Youden 指数确定最佳截断值

# ============================

best_cutoff <- pROC::coords(
  
  roc_obj,
  
  x = "best",
  
  best.method = "youden",
  
  ret = "threshold",
  
  transpose = FALSE
  
)

best_cutoff <- as.numeric(unlist(best_cutoff)[1])

cat("最佳截断值:", round(best_cutoff, 4), "\n")

# ============================

# 6. 计算 Accuracy、Sensitivity、Specificity

# ============================

pred_class <- factor(
  
  ifelse(
    
    pred_prob >= best_cutoff,
    
    levels(y)[2],
    
    levels(y)[1]
    
  ),
  
  levels = levels(y)
  
)

conf_mat <- table(
  
  Actual = y,
  
  Predicted = pred_class
  
)

print(conf_mat)

TN <- conf_mat[1, 1]

FP <- conf_mat[1, 2]

FN <- conf_mat[2, 1]

TP <- conf_mat[2, 2]

accuracy <- (TP + TN) / sum(conf_mat)

sensitivity <- ifelse(TP + FN > 0, TP / (TP + FN), NA)

specificity <- ifelse(TN + FP > 0, TN / (TN + FP), NA)

cat("Accuracy:", round(accuracy, 3), "\n")

cat("Sensitivity:", round(sensitivity, 3), "\n")

cat("Specificity:", round(specificity, 3), "\n")



# ============================

# 7. 汇总评价指标

# ============================

evaluation <- data.frame(
  
  Model = "SVM-RFE",
  
  Gene_Number = length(selected_genes),
  
  AUC = auc_value,
  
  AUC_95CI_Lower = as.numeric(auc_ci[1]),
  
  AUC_95CI_Upper = as.numeric(auc_ci[3]),
  
  Accuracy = accuracy,
  
  Sensitivity = sensitivity,
  
  Specificity = specificity
  
)

print(evaluation)

write.csv(
  
  evaluation,
  
  "SVM_RFE_evaluation.csv",
  
  row.names = FALSE
  
)

# ============================

# 8. 绘制 ROC 曲线

# ============================

roc_df <- data.frame(
  
  FPR = 1 - roc_obj$specificities,
  
  TPR = roc_obj$sensitivities
  
)

p <- ggplot(roc_df, aes(x = FPR, y = TPR)) +
  
  geom_line(linewidth = 1, color = "#4981bb") +
  
  geom_abline(
    
    intercept = 0,
    
    slope = 1,
    
    linetype = "dashed",
    
    color = "grey60"
    
  ) +
  
  annotate(
    
    "text",
    
    x = 0.55,
    
    y = 0.20,
    
    hjust = 0,
    
    label = paste0(
      
      "AUC = ", sprintf("%.3f", auc_value),
      
      "\nAUC 95% CI: ",
      
      sprintf("%.3f", auc_ci[1]), "-",
      
      sprintf("%.3f", auc_ci[3]),
      
      "\nAccuracy = ", sprintf("%.3f", accuracy),
      
      "\nSensitivity = ", sprintf("%.3f", sensitivity),
      
      "\nSpecificity = ", sprintf("%.3f", specificity)
      
    ),
    
    size = 4
    
  ) +
  
  labs(
    
    title = "SVM-RFE ROC Curve",
    
    x = "1 - Specificity",
    
    y = "Sensitivity"
    
  ) +
  
  coord_equal() +
  
  theme_classic(base_size = 14)

print(p)

ggsave(
  
  "/data/nas1/liky/project/FX65_KYGW-170308-1-FG/03_machine/SVM_RFE_ROC.pdf",
  
  plot = p,
  
  width = 6,
  
  height = 6
  
)

ggsave(
  
  "/data/nas1/liky/project/FX65_KYGW-170308-1-FG/03_machine/SVM_RFE_ROC.png",
  
  plot = p,
  
  width = 6,
  
  height = 6,
  
  dpi = 600
  
)


svm_plot_data <- results$results
svm_plot_data$col <- ifelse(svm_plot_data$Accuracy == max(svm_plot_data$Accuracy), '1', '0')
svm_plot_data$ErrorRate <- 1 - svm_plot_data$Accuracy
Accuracy_plot <- ggplot(svm_plot_data, aes(Variables, Accuracy)) +
  geom_line(linewidth = 0.8, color = "#4865A9") +
  geom_point(color = "#4865A9", size = 2, alpha = 0.6) +
  geom_point(data = subset(svm_plot_data, Accuracy == max(Accuracy)),
             color = "#EF8A43", size = 5, shape = 18) +
  annotate("text",
           x = svm_plot_data$Variables[which.max(svm_plot_data$Accuracy)] - 8,
           y = max(svm_plot_data$Accuracy) + 0.005,
           label = sprintf("Best: %d vars (Acc = %.3f)",
                           svm_plot_data$Variables[which.max(svm_plot_data$Accuracy)],
                           max(svm_plot_data$Accuracy)),
           color = "red", size = 4, hjust = 1, vjust = 0) +
  labs(x = "Number of Variables", y = "CV Accuracy") +
  theme_bw() +
  theme(panel.grid.minor = element_blank(),
        axis.title = element_text(size = 13),
        axis.text = element_text(size = 11),
        plot.margin = margin(10, 40, 10, 10, "pt"))

ErrorRate_plot <- ggplot(svm_plot_data, aes(Variables, ErrorRate)) +
  geom_line(linewidth = 0.8, color = "#4865A9") +
  geom_point(color = "#4865A9", size = 2, alpha = 0.6) +
  geom_point(data = subset(svm_plot_data, ErrorRate == min(ErrorRate)),
             color = "#EF8A43", size = 5, shape = 18) +
  annotate("text",
           x = svm_plot_data$Variables[which.min(svm_plot_data$ErrorRate)] - 8,
           y = min(svm_plot_data$ErrorRate) - 0.005,
           label = sprintf("Best: %d vars (Err = %.3f)",
                           svm_plot_data$Variables[which.min(svm_plot_data$ErrorRate)],
                           min(svm_plot_data$ErrorRate)),
           color = "red", size = 4, hjust = 1, vjust = 1) +
  labs(x = "Number of Variables", y = "CV Error Rate") +
  theme_bw() +
  theme(panel.grid.minor = element_blank(),
        axis.title = element_text(size = 13),
        axis.text = element_text(size = 11),
        plot.margin = margin(10, 40, 10, 10, "pt"))

combined_plot <- cowplot::plot_grid(Accuracy_plot, ErrorRate_plot, ncol = 2)

ggsave("04.SVM_RFE_plot.pdf", combined_plot, height = 5.5, width = 14)
ggsave("04.SVM_RFE_plot.png", combined_plot, height = 5.5, width = 14)

library(VennDiagram)

target1 <- read.csv("02.lasso_coefficients.csv")
target2 <- read.csv("03.SVM_RFE_gene.csv")



data_venn <- list(LASSO = target1$gene, SVM_RFE = target2$symbol)

library(VennDiagram)
library(grid)

only_LASSO <- length(setdiff(data_venn$LASSO, data_venn$SVM_RFE))
only_SVM   <- length(setdiff(data_venn$SVM_RFE, data_venn$LASSO))
both       <- length(intersect(data_venn$LASSO, data_venn$SVM_RFE))
total      <- length(union(data_venn$LASSO, data_venn$SVM_RFE))

label_LASSO <- paste0(only_LASSO, "\n(", round(only_LASSO/total*100, 1), "%)")
label_both  <- paste0(both,       "\n(", round(both/total*100, 1),       "%)")
label_SVM   <- paste0(only_SVM,   "\n(", round(only_SVM/total*100, 1),   "%)")

venn.plot <- venn.diagram(
  x = data_venn,
  category.names = c("LASSO", "SVM_RFE"),
  filename = NULL,
  output = TRUE,
  scaled = TRUE,
  fill = c("#EF8A43", "#4865A9"),
  cat.col = c("#EF8A43", "#4865A9"),
  cat.cex = 1.5,
  cex = 1.5,
  cat.dist = 0.08,
  margin = 0.1
)


venn.plot[[5]]$label <- label_LASSO   
venn.plot[[6]]$label <- label_SVM       
venn.plot[[7]]$label <- label_both    


ggsave('07.candidate_venn.png', venn.plot, height = 4, width = 5)
ggsave('07.candidate_venn.pdf', venn.plot, height = 4, width = 5)

inner_gene <- Reduce(base::intersect, list(target1$gene, target2$symbol)) %>% as.data.frame()
colnames(inner_gene) <- 'symbol'
write.csv(inner_gene, "08.candidate_gene.csv", row.names = F)
dat <- read.csv("/data/nas1/zhangyusheng_OD/project/03_project_job099/00_rawdata/dat.GSE56815.csv", row.names = 1)
train_Group <- read.csv("/data/nas1/zhangyusheng_OD/project/03_project_job099/00_rawdata/group.GSE56815.csv")
print(table(train_Group$group))  

# control      OP 
# 40      40
# hub gene 提取
common_genes <- read.csv('/data/nas1/zhangyusheng_OD/project/03_project_job099/03_machine/08.candidate_gene.csv')$symbol
hubgene <- common_genes
hubgene_expr <- dat[hubgene, ] %>% t() %>% as.data.frame()
hubgene_expr <- hubgene_expr[, order(colnames(hubgene_expr), decreasing = FALSE)]
plot_df <- hubgene_expr %>%
  tibble::rownames_to_column("sample") %>%
  dplyr::left_join(
    train_Group %>% dplyr::select(sample, group),
    by = "sample"
  ) %>%
  tidyr::pivot_longer(
    cols = -c(sample, group),
    names_to = "Gene",
    values_to = "value"
  ) %>%
  dplyr::mutate(
    value = as.numeric(value),
    group = factor(group, levels = c("control", "OP")),   # 明确顺序：control 先
    Gene  = factor(Gene)
  ) %>%
  dplyr::rename(Group = group)   
stopifnot(all(plot_df$sample %in% train_Group$sample))
library(rstatix)
stat_res <- plot_df %>%
  group_by(Gene) %>%
  wilcox_test(value ~ Group) %>%
  adjust_pvalue(method = "BH") %>%
  add_significance("p.adj")   

DEGs <- read.csv("/data/nas1/zhangyusheng_OD/project/03_project_job099/01_DEG/01.DEG_all_res.csv")
DEGs <- DEGs %>% dplyr::rename(Gene = gene)

stat_res <- stat_res %>%
  left_join(DEGs %>% dplyr::select(Gene, logFC, P.Value), by = "Gene")
#########################################
sig_genes <- stat_res %>% filter(P.Value != "ns")
cat("非ns的显著基因数量：", nrow(sig_genes), "\n")
cat("显著基因名称：\n"); print(sig_genes$Gene)
up_genes   <- sig_genes %>% filter(logFC > 0)
down_genes <- sig_genes %>% filter(logFC < 0)
cat("上调：", paste(up_genes$Gene, collapse = ", "), "\n")
cat("下调：", paste(down_genes$Gene, collapse = ", "), "\n")
#######################################
stat_res <- stat_res %>%
  mutate(stat = case_when(
    P.Value     <= 0.001 ~ "***",
    P.Value     <= 0.01  ~ "**",
    P.Value     <= 0.05  ~ "*",
    TRUE           ~ "ns"
  ))
library(dplyr)

stat_res2 <- stat_res %>%
  left_join(
    plot_df %>% 
      group_by(Gene) %>% 
      summarise(max_y = max(value, na.rm = TRUE)),
    by = "Gene"
  ) %>%
  mutate(y.position = max_y * 1.2)   # 1.2 通常比较合适，可微调到 1.15~1.3
stat_res2$y_pos <- NULL
library(ggpubr)
library(ggsci)
library(ggplot2)

p <- ggviolin(
  plot_df,
  x = "Group",
  y = "value",
  fill = "Group",
  add = "boxplot",
  palette = c("#104680", "#B72230"),          # 保持你原色
  add.params = list(fill = "white", color = "black", width = 0.2),
  legend = "none"                             # 可选：去掉图例，节省空间
) +
  stat_pvalue_manual(
    stat_res2,
    label = "stat",                         # 如果坚持用你原来的 stat 列也可以
    size = 5,
    family = "Times",
    color = "black",
    face = "bold",
    tip.length = 0.01
  ) +
  facet_wrap(~ Gene, nrow = 2, scales = "free_y") +
  theme_bw(base_size = 14) +
  theme(
    axis.title.x = element_blank(),
    strip.text = element_text(face = "bold", size = 12),
    strip.background = element_rect(fill = "grey95")
  ) +
  ylab("Expression value (log2)")
ggsave("08.hubgene_expression(train).pdf", p, width = 14, height = 10, dpi = 300)
ggsave("08.hubgene_expression(train).png", p, width = 14, height = 10, dpi = 300)
########################################

#验证集绘图

dat <- read.csv("/data/nas1/zhangyusheng_OD/project/03_project_job099/00_rawdata/dat.GSE7429.csv", row.names = 1)
train_Group <- read.csv("/data/nas1/zhangyusheng_OD/project/03_project_job099/00_rawdata/group.GSE7429.csv")

print(table(train_Group$group))  
# control      OP 
#  10      10
# hub gene 提取
common_genes <- read.csv('/data/nas1/zhangyusheng_OD/project/03_project_job099/03_machine/08.candidate_gene.csv')$symbol
hubgene <- common_genes
hubgene_expr <- dat[hubgene, ] %>% t() %>% as.data.frame()
hubgene_expr <- hubgene_expr[, order(colnames(hubgene_expr), decreasing = FALSE)]


plot_df <- hubgene_expr %>%
  tibble::rownames_to_column("sample") %>%
  dplyr::left_join(
    train_Group %>% dplyr::select(sample, group),
    by = "sample"
  ) %>%
  tidyr::pivot_longer(
    cols = -c(sample, group),
    names_to = "Gene",
    values_to = "value"
  ) %>%
  dplyr::mutate(
    value = as.numeric(value),
    group = factor(group, levels = c("control", "OP")),   # 明确顺序：control 先
    Gene  = factor(Gene)
  ) %>%
  dplyr::rename(Group = group)   

stopifnot(all(plot_df$sample %in% train_Group$sample))

library(rstatix)

stat_res <- plot_df %>%
  group_by(Gene) %>%
  wilcox_test(value ~ Group) %>%
  adjust_pvalue(method = "BH") %>%
  add_significance("p.adj")   # 用 p.adj.signif 更规范

# 合并原始 DEGs 的 logFC 等信息（如果你需要画图时显示 logFC，可选）
DEGs <- read.csv("/data/nas1/zhangyusheng_OD/project/03_project_job099/01_DEG/01.val_DEG_all_res.csv")
DEGs <- DEGs %>% dplyr::rename(Gene = gene)

stat_res <- stat_res %>%
  left_join(DEGs %>% dplyr::select(Gene, logFC, P.Value), by = "Gene")



# 生成星号（与你原来一致，但用 p 而非 p.adj，根据你需求可改成 p.adj）
stat_res <- stat_res %>%
  mutate(stat = case_when(
    p     <= 0.001 ~ "***",
    p     <= 0.01  ~ "**",
    p    <= 0.05  ~ "*",
    TRUE           ~ "ns"
  ))


library(dplyr)

stat_res2 <- stat_res %>%
  left_join(
    plot_df %>% 
      group_by(Gene) %>% 
      summarise(max_y = max(value, na.rm = TRUE)),
    by = "Gene"
  ) %>%
  mutate(y.position = max_y * 1.2)   # 1.2 通常比较合适，可微调到 1.15~1.3

# 移除可能的旧列干扰
stat_res2$y_pos <- NULL

library(ggpubr)
library(ggsci)
library(ggplot2)

p <- ggviolin(
  plot_df,
  x = "Group",
  y = "value",
  fill = "Group",
  add = "boxplot",
  palette = c("#104680", "#B72230"),         
  add.params = list(fill = "white", color = "black", width = 0.2),
  legend = "none"                            
) +
  stat_pvalue_manual(
    stat_res2,
    label = "stat",                         
    size = 5,
    family = "Times",
    color = "black",
    face = "bold",
    tip.length = 0.01
  ) +
  facet_wrap(~ Gene, nrow = 2, scales = "free_y") +
  theme_bw(base_size = 14) +
  theme(
    axis.title.x = element_blank(),
    strip.text = element_text(face = "bold", size = 12),
    strip.background = element_rect(fill = "grey95")
  ) +
  ylab("Expression value (log2)")
ggsave("09.hubgene_expression(val).pdf", p, width = 14, height = 10, dpi = 300)
ggsave("09.hubgene_expression(val).png", p, width = 14, height = 10, dpi = 300)
######三个基因过表达量验证
key_genes <- data.frame(symbol = c("NDUFB5",  "SRC"))
write.csv(key_genes, "keygene.csv", row.names = FALSE, quote = FALSE)

