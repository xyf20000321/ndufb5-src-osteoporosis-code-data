rm(list = ls())
setwd("/data/nas1/liky/project/FX65_KYGW-170308-1-FG/08_TF")
ORIGINAL_DIR <- "/data/nas1/liky/project/FX65_KYGW-170308-1-FG/"
output <- file.path(ORIGINAL_DIR, "08_TF")

library(dorothea)
library(viper)
library(Seurat)
library(dplyr)
library(tibble)
library(tidyr)
library(pheatmap)
library(ggplot2)
library(RColorBrewer)
library(grid)

# ── 读取单样本 OP ──────────────────────────────────────────────
seu <- readRDS('/data/nas1/zhangyusheng_OD/project/03_project_job099/04_singlecell/UMAP.rds')

if (inherits(seu[["RNA"]], "Assay5")) {
  seu[["RNA"]] <- as(seu[["RNA"]], "Assay")
}

cat("细胞数：", ncol(seu), "\n")
cat("细胞类型：", paste(unique(seu$cell.type), collapse = ", "), "\n")

# ── TF regulon ────────────────────────────────────────────────
dorothea_regulon_human <- get(data("dorothea_hs", package = "dorothea"))
regulon <- dorothea_regulon_human %>%
  filter(confidence %in% c("A", "B", "C"))
cat("TF数量：", length(unique(regulon$tf)), "\n")

seu <- run_viper(seu, regulon,
                 options = list(
                   method = "scale",
                   minsize = 4,
                   eset.filter = FALSE,
                   cores = 8,
                   verbose = FALSE
                 ))
# library(future)
# plan(sequential)
DefaultAssay(seu) <- "dorothea"
seu <- ScaleData(seu)
saveRDS(seu, file.path(output, "seu_merged_TF_activity.rds"))

cat("TF矩阵维度：", dim(seu@assays$dorothea@data), "\n")
cat("NA比例：",   round(sum(is.na(seu@assays$dorothea@data)) / length(seu@assays$dorothea@data), 4), "\n")
cat("零值比例：", round(sum(seu@assays$dorothea@data == 0, na.rm = TRUE) / length(seu@assays$dorothea@data), 4), "\n")

# ── 按细胞类型找差异 TF（替换原来的 OP vs OA）─────────────────
Idents(seu) <- factor(seu$cell.type)

tfa <- FindAllMarkers(
  seu,
  only.pos = TRUE,
  min.pct = 0.01,
  logfc.threshold = 0.05,
  min.cells.feature = 2,
  min.cells.group = 2,
  verbose = FALSE
)
tfa <- tfa[tfa$p_val_adj < 0.05, ]

write.csv(tfa, file.path(output, "diff_TF_by_celltype.csv"), quote = FALSE)  # ← 文件名改
cat("差异TF数量：", nrow(tfa), "\n")

tf_names_dorothea <- rownames(seu@assays$dorothea@data)
tf_names_tfa      <- unique(tfa$gene)
matched_tfs       <- tf_names_tfa[tf_names_tfa %in% tf_names_dorothea]
cat("匹配TF数量：", length(matched_tfs), "\n")

if (length(matched_tfs) < 5) {
  cat("差异TF过少，改用方差最大top50 TF\n")
  tf_var      <- apply(seu@assays$dorothea@scale.data, 1, var, na.rm = TRUE)
  matched_tfs <- names(sort(tf_var, decreasing = TRUE))[1:50]
}

viper_data <- GetAssayData(seu, slot = "scale.data", assay = "dorothea")[matched_tfs, ] %>%
  t() %>%
  as.data.frame()
viper_data$cell_type <- seu$cell.type[match(rownames(viper_data), names(seu$cell.type))]

# ── 图1：TF Activity 按细胞类型热图（替换原来的 OP vs OA 热图）─
tf_mean_ct <- viper_data %>%
  group_by(cell_type) %>%
  summarise(across(all_of(matched_tfs), \(x) mean(x, na.rm = TRUE))) %>%
  column_to_rownames("cell_type")

top30_ct    <- names(sort(apply(tf_mean_ct, 2, var, na.rm = TRUE), decreasing = TRUE))[1:min(30, length(matched_tfs))]
plot_mat_ct <- t(as.matrix(tf_mean_ct[, top30_ct]))
scaled_mat  <- t(scale(t(plot_mat_ct)))
scaled_mat[is.nan(scaled_mat)] <- 0

p1 <- pheatmap(
  scaled_mat,
  color             = colorRampPalette(rev(brewer.pal(11, "RdBu")))(100),
  cluster_cols      = TRUE,
  cluster_rows      = TRUE,
  clustering_method = "ward.D2",
  show_rownames     = TRUE,
  show_colnames     = TRUE,
  fontsize_row      = 11,
  fontsize_col      = 11,
  border_color      = NA,
  main              = "TF Activity by Cell Type (Top30, OP)",
  angle_col         = 45,
  silent            = TRUE
)

pdf(file.path(output, "TF_heatmap_celltype.pdf"), width = 12, height = 10, family = "serif")
grid.newpage(); grid.draw(p1$gtable)
dev.off()
png(file.path(output, "TF_heatmap_celltype.png"), width = 12, height = 10, units = "in", res = 300, family = "serif")
grid.newpage(); grid.draw(p1$gtable)
dev.off()

# # ── 图2：Monocytes 亚群 TF 热图 ────────────────────────────────
# seu_mono <- readRDS("/data/nas1/zhangyusheng_OD/project/03_project_job099/04_singlecell/seu_mono.rds")  # ← 读取已聚类的Monocytes
# 
# # 把 TF activity 转移到 seu_mono（只取交集细胞）
# mono_cells    <- colnames(seu_mono)
# tf_mat_mono   <- GetAssayData(seu, slot = "scale.data", assay = "dorothea")[, mono_cells]
# seu_mono[["dorothea"]] <- CreateAssayObject(data = tf_mat_mono)
# 
# tf_mean_mono <- t(tf_mat_mono) %>%
#   as.data.frame() %>%
#   mutate(cluster = seu_mono$seurat_clusters[match(rownames(.), colnames(seu_mono))]) %>%
#   group_by(cluster) %>%
#   summarise(across(everything(), \(x) mean(x, na.rm = TRUE))) %>%
#   column_to_rownames("cluster")
# 
# top20_mono    <- names(sort(apply(tf_mean_mono, 2, var, na.rm = TRUE), decreasing = TRUE))[1:min(20, ncol(tf_mean_mono))]
# plot_mat_mono <- t(as.matrix(tf_mean_mono[, top20_mono]))
# scaled_mono   <- t(scale(t(plot_mat_mono)))
# scaled_mono[is.nan(scaled_mono)] <- 0
# 
# p2 <- pheatmap(
#   scaled_mono,
#   color             = colorRampPalette(rev(brewer.pal(11, "RdBu")))(100),
#   cluster_cols      = TRUE,
#   cluster_rows      = TRUE,
#   clustering_method = "ward.D2",
#   show_rownames     = TRUE,
#   show_colnames     = TRUE,
#   fontsize_row      = 11,
#   fontsize_col      = 11,
#   border_color      = NA,
#   main              = "TF Activity in Monocyte Subclusters (Top20, OP)",
#   angle_col         = 45,
#   silent            = TRUE
# )
# 
# pdf(file.path(output, "TF_heatmap_Mono_subcluster.pdf"), width = 10, height = 10, family = "serif")
# grid.newpage(); grid.draw(p2$gtable)
# dev.off()
# png(file.path(output, "TF_heatmap_Mono_subcluster.png"), width = 10, height = 10, units = "in", res = 300, family = "serif")
# grid.newpage(); grid.draw(p2$gtable)
# dev.off()
# 
# # ── 图3：Monocytes 中 top10 TF 小提琴图（按亚群）──────────────
# top10_mono <- top20_mono[1:min(10, length(top20_mono))]
# 
# plot_df <- t(tf_mat_mono[top10_mono, ]) %>%
#   as.data.frame() %>%
#   mutate(cluster = as.character(seu_mono$seurat_clusters[match(rownames(.), colnames(seu_mono))])) %>%
#   pivot_longer(cols = all_of(top10_mono), names_to = "TF", values_to = "Activity")
# 
# p3 <- ggplot(plot_df, aes(x = TF, y = Activity, fill = cluster)) +
#   geom_violin(trim = FALSE, alpha = 0.8, position = position_dodge(0.9)) +
#   geom_boxplot(width = 0.1, position = position_dodge(0.9),
#                outlier.size = 0.3, alpha = 0.6) +
#   scale_fill_brewer(palette = "Set2") +
#   theme_bw(base_size = 13) +
#   theme(
#     axis.text.x     = element_text(angle = 45, hjust = 1, size = 11),
#     legend.position = "top",
#     panel.grid.minor = element_blank()
#   ) +
#   labs(
#     title = "Top10 TF Activity in Monocyte Subclusters (OP)",
#     x = "Transcription Factor", y = "Activity Score", fill = "Cluster"
#   )
# 
# ggsave(file.path(output, "TF_violin_Mono_top10.pdf"), p3, width = 14, height = 7)
# ggsave(file.path(output, "TF_violin_Mono_top10.png"), p3, width = 14, height = 7, dpi = 300)
