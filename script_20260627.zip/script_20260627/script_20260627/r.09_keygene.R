rm(list = ls())
setwd('')
ORIGINAL_DIR <- ""
output <- file.path(ORIGINAL_DIR, "09_keygene")

library(clusterProfiler)
library(enrichplot)
library(msigdbr)
library(ggplot2)
library(dplyr)

key_genes <- read.csv('')$symbol
res <- read.csv(file.path(ORIGINAL_DIR, "01_DEG/01.DEG_all_res.csv"))

gene_list <- res$logFC
names(gene_list) <- res$gene
gene_list <- sort(gene_list, decreasing = TRUE)
gene_list <- gene_list[!is.na(gene_list)]
gene_list <- gene_list[!duplicated(names(gene_list))]

cat("排序基因数：", length(gene_list), "\n")
cat("关键基因是否在排序列表中：\n")
print(key_genes %in% names(gene_list))

kegg_sets <- msigdbr(species = "Homo sapiens", category = "C2", subcategory = "CP:KEGG") %>%
  dplyr::select(gs_name, gene_symbol)

gsea_kegg <- GSEA(
  geneList     = gene_list,
  TERM2GENE    = kegg_sets,
  minGSSize    = 10,
  maxGSSize    = 500,
  pvalueCutoff = 0.05,
  pAdjustMethod = "BH",
  nPermSimple  = 1000,
  eps          = 0,
  seed         = 42,
  verbose      = FALSE
)

cat("KEGG显著通路数：", nrow(gsea_kegg@result), "\n")
write.csv(gsea_kegg@result, file.path(output, "GSEA_KEGG_all.csv"), quote = FALSE, row.names = FALSE)

go_sets <- msigdbr(species = "Homo sapiens", category = "C5") %>%
  dplyr::select(gs_name, gene_symbol)

gsea_go <- GSEA(
  geneList      = gene_list,
  TERM2GENE     = go_sets,
  minGSSize     = 10,
  maxGSSize     = 500,
  pvalueCutoff  = 0.05,
  pAdjustMethod = "BH",
  nPermSimple   = 1000,
  eps           = 0,
  seed          = 42,
  verbose       = FALSE
)

cat("GO显著通路数：", nrow(gsea_go@result), "\n")
write.csv(gsea_go@result, file.path(output, "GSEA_GO_all.csv"), quote = FALSE, row.names = FALSE)

filter_gsea <- function(gsea_result) {
  gsea_result@result <- gsea_result@result %>%
    filter(abs(NES) > 1, pvalue < 0.05, qvalue < 0.25)
  return(gsea_result)
}

gsea_kegg_sig <- filter_gsea(gsea_kegg)
gsea_go_sig   <- filter_gsea(gsea_go)

cat("KEGG筛选后通路数：", nrow(gsea_kegg_sig@result), "\n")
cat("GO筛选后通路数：",   nrow(gsea_go_sig@result), "\n")

write.csv(gsea_kegg_sig@result, file.path(output, "GSEA_KEGG_sig.csv"), quote = FALSE, row.names = FALSE)
write.csv(gsea_go_sig@result,   file.path(output, "GSEA_GO_sig.csv"),   quote = FALSE, row.names = FALSE)

find_keygene_pathways <- function(gsea_result, key_genes, label = "KEGG") {
  related <- gsea_result@result %>%
    filter(sapply(core_enrichment, function(x) {
      any(key_genes %in% strsplit(x, "/")[[1]])
    }))
  cat(label, "中包含关键基因的通路数：", nrow(related), "\n")
  write.csv(related, file.path(output, paste0("GSEA_", label, "_keygene_pathways.csv")),
            quote = FALSE, row.names = FALSE)
  return(related)
}

kegg_related <- find_keygene_pathways(gsea_kegg_sig, key_genes, "KEGG")
go_related   <- find_keygene_pathways(gsea_go_sig,   key_genes, "GO")

plot_gsea_curves <- function(gsea_result, related_df, label, top_n = 5) {
  if (nrow(related_df) == 0) {
    cat(label, "无关键基因相关通路，跳过富集曲线图\n")
    return(NULL)
  }
  
  plot_ids <- related_df %>%
    arrange(pvalue) %>%
    slice_head(n = top_n) %>%
    pull(ID)
  
  p <- gseaplot2(
    gsea_result,
    geneSetID = plot_ids,
    title     = paste0(label, ": Key Gene Related Pathways"),
    color     = scales::hue_pal()(length(plot_ids))
  )
  
  ggsave(file.path(output, paste0("1_GSEA_", label, "_curve.pdf")),
         p, width = 12, height = 8)
  ggsave(file.path(output, paste0("1_GSEA_", label, "_curve.png")),
         p, width = 12, height = 8, dpi = 300)
  cat(label, "富集曲线图已保存\n")
  return(p)
}

plot_gsea_curves(gsea_kegg_sig, kegg_related, "KEGG")
plot_gsea_curves(gsea_go_sig,   go_related,   "GO", top_n = 5)

plot_ridge <- function(gsea_result, related_df, label, top_n = 10) {
  if (nrow(related_df) == 0) {
    cat(label, "无关键基因相关通路，跳过山脊图\n")
    return(NULL)
  }
  
  plot_ids           <- related_df %>% arrange(pvalue) %>% slice_head(n = top_n) %>% pull(ID)
  gsea_subset        <- gsea_result
  gsea_subset@result <- gsea_result@result %>% filter(ID %in% plot_ids)
  
  p <- ridgeplot(gsea_subset, fill = "pvalue", core_enrichment = TRUE) +
    scale_fill_gradient(low = "#D73027", high = "#4575B4") +
    labs(title = paste0(label, ": Key Gene Related Pathways (Ridgeplot)"),
         x = "Gene Rank", y = "Pathway") +
    theme_bw(base_size = 12) +
    theme(
      plot.title  = element_text(hjust = 0.5, size = 13, face = "bold"),
      axis.text.y = element_text(size = 10)
    )
  
  ggsave(file.path(output, paste0("2_GSEA_", label, "_ridge.pdf")), p, width = 14, height = 8)
  ggsave(file.path(output, paste0("2_GSEA_", label, "_ridge.png")), p, width = 14, height = 8, dpi = 300)
  cat(label, "山脊图已保存\n")
  return(p)
}

plot_ridge(gsea_kegg_sig, kegg_related, "KEGG")
plot_ridge(gsea_go_sig,   go_related,   "GO", top_n = 10)

plot_gsea_by_gene <- function(gsea_result, gene, label, top_n = 5) {
  related <- gsea_result@result %>%
    filter(sapply(core_enrichment, function(x) {
      gene %in% strsplit(x, "/")[[1]]
    })) %>%
    arrange(pvalue) %>%
    slice_head(n = top_n)
  
  if (nrow(related) == 0) {
    cat(label, gene, "无相关通路，跳过\n")
    return(NULL)
  }
  
  cat(label, "-", gene, "相关通路数：", nrow(related), "\n")
  plot_ids <- related$ID
  
  p_curve <- gseaplot2(
    gsea_result,
    geneSetID = plot_ids,
    title = paste0(label, ": ", gene, " Related Pathways (Top", top_n, ")"),
    color = scales::hue_pal()(length(plot_ids))
  )
  ggsave(file.path(output, paste0("3_GSEA_", label, "_", gene, "_curve.pdf")),
         p_curve, width = 12, height = 10)
  ggsave(file.path(output, paste0("3_GSEA_", label, "_", gene, "_curve.png")),
         p_curve, width = 12, height = 10, dpi = 300)
  
  gsea_subset <- gsea_result
  gsea_subset@result <- gsea_result@result %>% filter(ID %in% plot_ids)
  p_ridge <- ridgeplot(gsea_subset, fill = "pvalue", core_enrichment = TRUE) +
    scale_fill_gradient(low = "#D73027", high = "#4575B4") +
    labs(title = paste0(label, ": ", gene, " Related Pathways (Ridgeplot)"),
         x = "Gene Rank", y = "Pathway") +
    theme_bw(base_size = 12) +
    theme(
      plot.title  = element_text(hjust = 0.5, size = 13, face = "bold"),
      axis.text.y = element_text(size = 10)
    )
  ggsave(file.path(output, paste0("3_GSEA_", label, "_", gene, "_ridge.pdf")),
         p_ridge, width = 14, height = 8)
  ggsave(file.path(output, paste0("3_GSEA_", label, "_", gene, "_ridge.png")),
         p_ridge, width = 14, height = 8, dpi = 300)
  
  cat(label, "-", gene, "图已保存\n")
}

for (gene in key_genes) {
  plot_gsea_by_gene(gsea_kegg_sig, gene, "KEGG", top_n = 5)
  plot_gsea_by_gene(gsea_go_sig,   gene, "GO",   top_n = 5)
}
