rm(list = ls())
setwd('')
ORIGINAL_DIR <- ""
output <- file.path(ORIGINAL_DIR, "10_immune")

library(GSVA)
library(msigdbr)
library(pheatmap)
library(ggplot2)
library(dplyr)
library(tidyr)
library(tibble)
library(RColorBrewer)
library(grid)
library(ggpubr)
library(rstatix)
library(corrplot)

expr <- read.csv("",
                 row.names=1, check.names=FALSE)
group <- read.csv("")
group$group <- factor(group$group, levels=c("control","OP"))
expr <- expr[, group$sample]

immune_gs <- msigdbr(species="Homo sapiens", category="C8") %>%
  filter(grepl("IMMUNE|immune|NK|T.cell|B.cell|Monocyte|Macrophage|Neutrophil|Dendritic|
                Mast|Eosinophil|Basophil|MDSC|Treg|Plasma", gs_name)) %>%
  dplyr::select(gs_name, gene_symbol)
immune_list <- split(immune_gs$gene_symbol, immune_gs$gs_name)
cat("免疫细胞基因集数量：", length(immune_list), "\n")

ssgsea_res <- gsva(as.matrix(expr),
                   immune_list,
                   method="ssgsea",
                   kcdf="Gaussian",
                   mx.diff=TRUE)
write.csv(ssgsea_res, file.path(output, "ssgsea_immune_scores.csv"))

mat <- ssgsea_res
anno_col <- data.frame(Group=group$group, row.names=group$sample)
ann_colors <- list(Group=c(control="#F28500", OP="#1874CD"))

p_heat <- pheatmap(mat,
                   annotation_col=anno_col,
                   annotation_colors=ann_colors,
                   color=colorRampPalette(rev(brewer.pal(11,"RdBu")))(100),
                   show_colnames=FALSE,
                   cluster_cols=FALSE,
                   cluster_rows=TRUE,
                   clustering_method="ward.D2",
                   fontsize_row=9,
                   border_color=NA,
                   main="Immune Cell Infiltration (ssGSEA)",
                   silent=TRUE)

pdf(file.path(output,"01_immune_heatmap.pdf"), width=14, height=10, family="serif")
grid.newpage(); grid.draw(p_heat$gtable)
dev.off()
png(file.path(output,"01_immune_heatmap.png"), width=14, height=10,
    units="in", res=300, family="serif")
grid.newpage(); grid.draw(p_heat$gtable)
dev.off()

plot_df <- as.data.frame(t(ssgsea_res)) %>%
  rownames_to_column("sample") %>%
  left_join(group, by="sample") %>%
  pivot_longer(cols=-c(sample,group), names_to="CellType", values_to="Score") %>%
  mutate(group=factor(group, levels=c("control","OP")))

stat_res <- plot_df %>%
  group_by(CellType) %>%
  wilcox_test(Score ~ group) %>%
  adjust_pvalue(method="BH") %>%
  add_significance("p") %>%
  mutate(y.position=max(plot_df$Score)*1.05)

p_box <- ggplot(plot_df, aes(x=CellType, y=Score, fill=group)) +
  geom_boxplot(outlier.size=0.5, width=0.6) +
  stat_pvalue_manual(stat_res, label="p.signif", size=3, tip.length=0.01) +
  scale_fill_manual(values=c(control="#F28500", OP="#1874CD")) +
  theme_bw(base_size=11) +
  theme(axis.text.x=element_text(angle=45, hjust=1, size=8),
        legend.position="top",
        panel.grid.minor=element_blank()) +
  labs(x="Immune Cell Type", y="ssGSEA Score", fill="Group")

ggsave(file.path(output,"02_immune_boxplot.pdf"), p_box, width=20, height=8)
ggsave(file.path(output,"02_immune_boxplot.png"), p_box, width=20, height=8, dpi=300)

key_genes <- read.csv("")$symbol
key_expr <- as.data.frame(t(expr[key_genes, ]))
immune_df <- as.data.frame(t(ssgsea_res))
cor_df <- cbind(key_expr, immune_df)

r_mat <- matrix(NA, nrow=length(key_genes), ncol=ncol(immune_df),
                dimnames=list(key_genes, colnames(immune_df)))
p_mat <- r_mat

for(g in key_genes){
  for(ct in colnames(immune_df)){
    test <- cor.test(cor_df[[g]], cor_df[[ct]], method="spearman")
    r_mat[g, ct] <- test$estimate
    p_mat[g, ct] <- test$p.value
  }
}

write.csv(r_mat, file.path(output,"cor_r_matrix.csv"))
write.csv(p_mat, file.path(output,"cor_p_matrix.csv"))

sig_mask <- p_mat < 0.05 & abs(r_mat) >= 0.3
keep_ct <- colnames(r_mat)[apply(sig_mask, 2, any)]
r_plot <- t(r_mat[, keep_ct])
p_plot <- t(p_mat[, keep_ct])

pdf(file.path(output,"03_immune_keygene_corrplot.pdf"), width=14, height=14, family="serif")
corrplot(r_plot, method="square", col=colorRampPalette(c("#1874CD","white","#FED82F"))(200),
         p.mat=p_plot, sig.level=c(0.001,0.01,0.05),
         insig="label_sig", pch.col="black", pch.cex=0.8,
         tl.col="black", tl.cex=0.7, tl.srt=45,
         cl.ratio=0.1, mar=c(0,0,2,0),
         title="Spearman Correlation: Key Genes vs Immune Cells")
dev.off()
png(file.path(output,"03_immune_keygene_corrplot.png"), width=14, height=14,
    units="in", res=300, family="serif")
corrplot(r_plot, method="square", col=colorRampPalette(c("#1874CD","white","#FED82F"))(200),
         p.mat=p_plot, sig.level=c(0.001,0.01,0.05),
         insig="label_sig", pch.col="black", pch.cex=0.8,
         tl.col="black", tl.cex=0.7, tl.srt=45,
         cl.ratio=0.1, mar=c(0,0,2,0),
         title="Spearman Correlation: Key Genes vs Immune Cells")
dev.off()
