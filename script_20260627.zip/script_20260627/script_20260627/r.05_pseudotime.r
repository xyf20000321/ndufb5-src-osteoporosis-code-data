rm(list = ls())
setwd("/data/nas1/liky/project/FX65_KYGW-170308-1-FG/05_pseudotime")
ORIGINAL_DIR <- "/data/nas1/liky/project/FX65_KYGW-170308-1-FG/"
output <- file.path(ORIGINAL_DIR, "05_pseudotime")

library(monocle)
library(Seurat)
library(dplyr)
library(ggplot2)
library(grid)

sce <- readRDS('/data/nas1/zhangyusheng_OD/project/03_project_job099/04_singlecell/seu_mono.rds')
key_genes <- read.csv('/data/nas1/zhangyusheng_OD/project/03_project_job099/03_machine/keygene.csv')$symbol

expr_matrix <- as(as.matrix(sce@assays$RNA@layers$counts), 'sparseMatrix')
p_data <- sce@meta.data
f_data <- data.frame(gene_short_name = row.names(sce), row.names = row.names(sce))
pd <- new('AnnotatedDataFrame', data = p_data)
fd <- new('AnnotatedDataFrame', data = f_data)
cds <- newCellDataSet(
  expr_matrix,
  phenoData = pd,
  featureData = fd,
  lowerDetectionLimit = 0.5,
  expressionFamily = negbinomial.size()
)

cds <- estimateSizeFactors(cds)
cds <- estimateDispersions(cds)

expressed_genes <- VariableFeatures(sce)
cds <- setOrderingFilter(cds, expressed_genes)

p_order <- plot_ordering_genes(cds)
ggsave(file.path(output, "1_ordering_genes_plot.pdf"), p_order, width = 10, height = 6)
ggsave(file.path(output, "1_ordering_genes_plot.png"), p_order, width = 10, height = 6, dpi = 300)

cds <- reduceDimension(cds, max_components = 2, method = 'DDRTree')
cds <- orderCells(cds)
cds <- orderCells(cds, root_state = 4)  
p_pseudo <- plot_cell_trajectory(cds, color_by = "Pseudotime",
                                 cell_size = 1.5, cell_link_size = 0.5) +
  scale_color_gradient(low = "#A6CEE3", high = "#E31A1C") +
  ggtitle("Pseudotime Trajectory of Monocytes") +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
        panel.background = element_rect(fill = "white", color = NA),
        plot.background = element_rect(fill = "white", color = NA))

ggsave(file.path(output, "2_pseudotime_trajectory.pdf"), p_pseudo, width = 8, height = 6)
ggsave(file.path(output, "2_pseudotime_trajectory.png"), p_pseudo, width = 8, height = 6, dpi = 300)

p_clusters <- plot_cell_trajectory(cds, color_by = "seurat_clusters",
                                   cell_size = 1.5, cell_link_size = 0.5) +
  ggtitle("Trajectory Colored by Seurat Clusters") +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
        panel.background = element_rect(fill = "white", color = NA),
        plot.background = element_rect(fill = "white", color = NA))

ggsave(file.path(output, "3_trajectory_by_clusters.pdf"), p_clusters, width = 8, height = 6)
ggsave(file.path(output, "3_trajectory_by_clusters.png"), p_clusters, width = 8, height = 6, dpi = 300)
for (gene in key_genes) {
  if (gene %in% row.names(fData(cds))) {
    p_gene <- plot_genes_in_pseudotime(
      cds[gene, ],
      color_by = "cell.type",   
      min_expr = 0.01,
      cell_size = 1.5
    ) +
      scale_color_brewer(palette = "Set2") +  
      ggtitle(paste("Expression of", gene, "along Pseudotime (OP)")) +
      theme_minimal() +
      theme(plot.title = element_text(hjust = 0.5, size = 12, face = "bold"))
    
    ggsave(file.path(output, paste0("4_", gene, "_pseudotime_expression.pdf")),
           p_gene, width = 8, height = 6)
    ggsave(file.path(output, paste0("4_", gene, "_pseudotime_expression.png")),
           p_gene, width = 8, height = 6, dpi = 300)
    cat(gene, "表达图已保存\n")
  } else {
    cat(gene, "在cds中不存在，跳过\n")
  }
}

p_heatmap <- plot_pseudotime_heatmap(
  cds[key_genes, ],
  cluster_rows = TRUE,
  cores = 8,
  show_rownames = TRUE,
  return_heatmap = TRUE
)

pdf(file.path(output, "5_hubgene_pseudotime_heatmap.pdf"), width = 6, height = 4, family = "serif")
grid.newpage()
grid.draw(p_heatmap$gtable)
dev.off()

png(file.path(output, "5_hubgene_pseudotime_heatmap.png"), width = 6, height = 4,
    units = "in", res = 300, family = "serif")
grid.newpage()
grid.draw(p_heatmap$gtable)
dev.off()

saveRDS(cds, file.path(output, "cds_Monocytes_monocle.rds"))
