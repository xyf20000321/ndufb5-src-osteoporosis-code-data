rm(list = ls())
setwd('')
ORIGINAL_DIR <- ""
output <- file.path(ORIGINAL_DIR, "01_DEG")

train_expr <- read.csv('',row.names = 1,
                       check.names = FALSE)
train_group <- read.csv('')

table(train_group$group)

library(limma)
group_list <- train_group
expr <- as.data.frame(lapply(train_expr, as.numeric))
max(expr)

rownames(expr) <- rownames(train_expr)
group_list$group <- factor(group_list$group)
design <- model.matrix(~0 + group_list$group)
rownames(design) <- group_list$sample
colnames(design) <- levels(group_list$group)
compare <- makeContrasts("OP-control", levels = design)
compare
fit <- lmFit(expr, design)
fit2 <- contrasts.fit(fit, compare)
fit3 <- eBayes(fit2)
res <- topTable(fit3, coef = 1, number = Inf, sort.by = "logFC",
                adjust.method = "BH")
dim(res)

colnames(res)
res$gene <- rownames(res)
write.csv(res, file = paste0(output, "/01.DEG_all_res.csv"), quote = FALSE, row.names = FALSE)
res <- read.csv("01.DEG_all_res.csv")
logfc <- 0.1
summary(res$P.Value)
res$change <- as.factor(
  ifelse(res$P.Value < 0.05 & abs(res$logFC) > logfc,
         ifelse(res$logFC > logfc,'Up','Down'),'Not')
)
table(res$change)

sig_res <- res[res$change %in% c("Up", "Down"), ]
head(sig_res$gene)
table(sig_res$change)
write.csv(sig_res, file = paste0(output, "/02.DEG_sig_res.csv"), quote = FALSE, row.names = FALSE)

library(ggplot2)
library(ggthemes)
library(RColorBrewer)
library(Ipaper)
library(scales)
library(ggrepel)
res <- read.csv("01.DEG_all_res.csv")
sig_res <- read.csv("02.DEG_sig_res.csv")
top_up <- sig_res %>%
  arrange(desc(logFC)) %>%
  clusterProfiler::slice(1:10) %>%
  pull(gene)
top_down <- sig_res %>%
  arrange(logFC) %>%
  clusterProfiler::slice(1:10) %>%
  pull(gene)
genes_use <- unique(c(top_up, top_down))
expr <- read.csv('',row.names = 1,
                 check.names = FALSE)
group <- read.csv('')
group$group <- factor(group$group, levels = c("control", "OP"))
common_samples <- base::intersect(colnames(expr), group$sample)
expr <- expr[, common_samples]
group <- group[match(common_samples, group$sample), ]
stopifnot(identical(colnames(expr), group$sample))
mat <- expr[rownames(expr) %in% genes_use, ]
mat <- t(scale(t(mat)))
order_idx <- order(group$group)
mat <- mat[, order_idx]
group <- group[order_idx, ]
library(ComplexHeatmap)
library(circlize)
library(grid)
ha <- HeatmapAnnotation(
  Group = group$group,
  col = list(Group = c("OP" = "#FF7F24", "control" = "#5F9EA0"))
)
pdf("01.heatmap.pdf", width = 6, height = 6, family = "Times")
Heatmap(
  mat,
  name = "Z-score",
  top_annotation = ha,
  show_column_names = FALSE,
  show_row_names = TRUE,
  row_names_gp = gpar(fontsize = 9),
  cluster_rows = TRUE,
  cluster_columns = FALSE,
  col = colorRamp2(c(-2, 0, 2), c("#87CEEB", "white", "#DB7093"))
)
dev.off()
png("01.heatmap.png", width = 6, height = 6, units = "in", res = 600)
Heatmap(
  mat,
  name = "Z-score",
  top_annotation = ha,
  show_column_names = FALSE,
  show_row_names = TRUE,
  row_names_gp = gpar(fontsize = 9),
  cluster_rows = TRUE,
  cluster_columns = FALSE,
  col = colorRamp2(c(-2, 0, 2), c("#87CEEB", "white", "#DB7093"))
)
dev.off()

library(ggplot2)
library(ggrepel)
res$change <- "Not"
res$change[res$P.Value < 0.05 & res$logFC > 0] <- "Up"
res$change[res$P.Value < 0.05 & res$logFC < 0] <- "Down"
res$change <- factor(res$change, levels = c("Down", "Not", "Up"))
significant_res <- res[res$P.Value < 0.05, ]
up_10 <- head(significant_res[order(significant_res$logFC, decreasing = TRUE), ], 10)
down_10 <- head(significant_res[order(significant_res$logFC, decreasing = FALSE), ], 10)
dat_rep <- rbind(up_10, down_10)
head(dat_rep)
volcano_plot <- ggplot(res, aes(
  x = logFC,
  y = -log10(P.Value),
  color = change
)) +
  geom_point(size = 1.2, alpha = 0.4) +
  scale_color_manual(values = c(
    "Down" = "#5F9EA0",
    "Not" = "darkgray",
    "Up" = "#FF7F24"
  )) +
  geom_vline(xintercept = c(-0.5, 0.5),
             linetype = "dashed", color = "darkgray") +
  geom_hline(yintercept = -log10(0.05),
             linetype = "dashed", color = "darkgray") +
  theme_bw(base_size = 12, base_family = "Times") +
  theme(
    panel.grid = element_blank(),
    legend.title = element_blank(),
    legend.text = element_text(face = "bold", size = 13),
    axis.text = element_text(face = "bold", size = 13),
    axis.title = element_text(face = "bold", size = 14)
  ) +
  geom_label_repel(
    data = dat_rep,
    aes(label = gene),
    size = 4,
    max.overlaps = 20,
    box.padding = 0.5,
    point.padding = 0.8,
    segment.color = "black",
    show.legend = FALSE
  ) +
  labs(
    x = "log2 (Fold Change)",
    y = "-log10 (P.Value)"
  )
ggsave(paste0(output, "/02.volcano.png"),
       volcano_plot, width = 8, height = 6, dpi = 600)
ggsave(paste0(output, "/02.volcano.pdf"),
       volcano_plot, width = 8, height = 6)

rm(list = ls())
setwd('')
ORIGINAL_DIR <- ""
output <- file.path(ORIGINAL_DIR, "01_DEG")
train_expr <- read.csv('',row.names = 1,
                       check.names = FALSE)
train_group <- read.csv('')
table(train_group$group)

library(limma)
group_list <- train_group
expr <- as.data.frame(lapply(train_expr, as.numeric))
max(expr)

rownames(expr) <- rownames(train_expr)
group_list$group <- factor(group_list$group)
design <- model.matrix(~0 + group_list$group)
rownames(design) <- group_list$sample
colnames(design) <- levels(group_list$group)
compare <- makeContrasts("OP-control", levels = design)
compare
fit <- lmFit(expr, design)
fit2 <- contrasts.fit(fit, compare)
fit3 <- eBayes(fit2)
res <- topTable(fit3, coef = 1, number = Inf, sort.by = "logFC",
                adjust.method = "BH")
dim(res)

colnames(res)
res$gene <- rownames(res)
write.csv(res, file = paste0(output, "/01.val_DEG_all_res.csv"), quote = FALSE, row.names = FALSE)
res <- read.csv("01.val_DEG_all_res.csv")
logfc <- 0
summary(res$P.Value)
res$change <- as.factor(
  ifelse(res$P.Value < 0.05 & abs(res$logFC) > logfc,
         ifelse(res$logFC > logfc,'Up','Down'),'Not')
)
table(res$change)

sig_res <- res[res$change %in% c("Up", "Down"), ]
head(sig_res$gene)
table(sig_res$change)
write.csv(sig_res, file = paste0(output, "/02.val_DEG_sig_res.csv"), quote = FALSE, row.names = FALSE)

