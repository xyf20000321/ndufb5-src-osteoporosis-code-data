rm(list = ls())
setwd('')
ORIGINAL_DIR <- ""
output <- file.path(ORIGINAL_DIR, "11_graphban")

library(igraph)
library(ggraph)
library(tidyverse)

edges <- read.csv("")
top30 <- read.csv("")

top30$label <- ifelse(grepl("CIDNone", top30$PubChem_CID), top30$Drug_ID, top30$PubChem_CID)
edges$Drug_label <- ifelse(grepl("CIDNone", edges$Drug_label), edges$Drug, edges$Drug_label)
edges2 <- edges %>% select(Drug=Drug_label, Target, Score)

all_nodes <- c(unique(edges2$Drug), "NDUFB5", "SRC")
g <- graph_from_data_frame(edges2, directed=FALSE, vertices=all_nodes)
V(g)$type <- ifelse(V(g)$name %in% c("NDUFB5","SRC"), "Target", "Drug")

set.seed(123)
layout <- create_layout(g, layout="fr")
layout$x[layout$name == "NDUFB5"] <- -1.5
layout$y[layout$name == "NDUFB5"] <- 0.5
layout$x[layout$name == "SRC"] <- 1.5
layout$y[layout$name == "SRC"] <- -0.5

p <- ggraph(layout) +
  geom_edge_link(aes(width=Score, alpha=Score), color="#2E86C1") +
  scale_edge_width(range=c(0.3, 1.5)) +
  scale_edge_alpha(range=c(0.2, 0.7)) +
  geom_node_point(aes(color=type, size=type)) +
  scale_color_manual(values=c("Target"="#E74C3C", "Drug"="#2E86C1")) +
  scale_size_manual(values=c("Target"=12, "Drug"=5)) +
  geom_node_text(aes(label=name),
                 size=ifelse(V(g)$type=="Target", 5, 2.8),
                 fontface=ifelse(V(g)$type=="Target", "bold", "plain"),
                 repel=TRUE, max.overlaps=50) +
  theme_graph(base_family="sans") +
  labs(title="Drug-Target Interaction Network",
       subtitle="Top 30 Candidates vs NDUFB5 & SRC",
       color="Node Type", size="Node Type") +
  guides(edge_width="none", edge_alpha="none")

ggsave(file.path(output, "drug_target_network.pdf"), p, width=16, height=13)
ggsave(file.path(output, "drug_target_network.png"), p, width=16, height=13, dpi=300)

library(httr)
library(jsonlite)

cids <- c(71691626, 24736639, 51537823)

get_pubchem_info <- function(cid) {
  url <- paste0(
    "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/", cid,
    "/property/MolecularFormula,MolecularWeight,IUPACName,IsomericSMILES/JSON"
  )
  res <- GET(url)
  dat <- fromJSON(content(res, "text", encoding = "UTF-8"))
  return(dat$PropertyTable$Properties)
}

drug_info <- do.call(rbind, lapply(cids, get_pubchem_info))
print(drug_info)
write.csv(drug_info, file.path(output, "Top3_drug_pubchem_info.csv"), 
          row.names = FALSE, quote = FALSE)
