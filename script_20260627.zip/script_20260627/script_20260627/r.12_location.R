rm(list = ls())
setwd('')
ORIGINAL_DIR <- ""
output <- file.path(ORIGINAL_DIR, "12_location")

library(AnnoProbe)
library(circlize)
library(RCircos)

hub_gene <- read.csv('')$symbol
hubgene_chr <- annoGene(hub_gene,
                        ID_type = 'SYMBOL',
                        species = 'human')
hubgene_chr <- hubgene_chr[,c(4:6,1)]
colnames(hubgene_chr) = c("Chromosome", "chromStart", "chromEnd", "Gene" )
write.csv(hubgene_chr,'01.OP_gene_pos.csv', row.names = FALSE) 
RCircos.Gene.Label.Data <- hubgene_chr
pdf(file = paste0("02.OP_hubgene_RCircos.pdf"), width = 7, height = 7)
data(UCSC.HG19.Human.CytoBandIdeogram)
cyto.info <- UCSC.HG19.Human.CytoBandIdeogram
chr.exclude <- NULL
tracks.inside <- 20
tracks.outside <- 0
RCircos.Set.Core.Components(cyto.info, chr.exclude, tracks.inside, tracks.outside)
RCircos.Set.Plot.Area()
RCircos.Chromosome.Ideogram.Plot()
side <- "in"
track.num <- 1
name.col <- 4
rcircos.params <- RCircos.Get.Plot.Parameters()
rcircos.params$text.size = 1.2
RCircos.Reset.Plot.Parameters(rcircos.params)
RCircos.Gene.Connector.Plot(RCircos.Gene.Label.Data, track.num, side)
RCircos.Gene.Name.Plot(RCircos.Gene.Label.Data, name.col, track.num + 1, side) 
dev.off()
png(file = paste0("02.OP_hubgene_RCircos.png"), width = 7, height=7, units="in", res=600)
RCircos.Set.Core.Components(cyto.info, chr.exclude, tracks.inside, tracks.outside)
RCircos.Set.Plot.Area()
RCircos.Chromosome.Ideogram.Plot()
side <- "in"
track.num <- 1
name.col <- 4
rcircos.params <- RCircos.Get.Plot.Parameters()
rcircos.params$text.size = 1.2
RCircos.Reset.Plot.Parameters(rcircos.params)
RCircos.Gene.Connector.Plot(RCircos.Gene.Label.Data, track.num, side)
RCircos.Gene.Name.Plot(RCircos.Gene.Label.Data, name.col, track.num + 1, side)
dev.off()

