rm(list = ls())
setwd('')
ORIGINAL_DIR <- ""
output <- file.path(ORIGINAL_DIR, "13_rnalocate")

library(tidyverse)
library(data.table)

key_genes <- read.csv('')$symbol
rnalocate <- fread(' subcellular localization information.txt')

rnalocate2 <- rnalocate %>% 
  filter(Species == 'Homo sapiens') %>%
  filter(RNA_Type == 'mRNA') %>% 
  filter(RNA_Symbol %in% key_genes) %>% 
  dplyr::select(RNA_Symbol, Subcellular_Localization, RNALocate_Score) %>% 
  unique() %>% 
  mutate(RNA_Symbol = fct_relevel(RNA_Symbol, key_genes)) %>% 
  mutate(RNALocate_Score = as.numeric(sprintf("%.3f", RNALocate_Score)))

print(rnalocate2)
write_csv(rnalocate2, file.path(output, '01_rnalocate.csv'))

p <- ggplot(rnalocate2, aes(x = RNA_Symbol, y = Subcellular_Localization)) +
  geom_tile(aes(fill = RNALocate_Score), color = "black") +
  geom_text(aes(label = sprintf("%.3f", RNALocate_Score)), color = "black", size = 4) +
  scale_fill_gradientn(
    colors = c("#FFFFFF", "#DEEBF7", "#9ECAE1", "#4292C6", "#2171B5", "#084594"),
    values = scales::rescale(c(0, 0.2, 0.4, 0.6, 0.8, 1)),
    limit = c(0, 1), name = "Score") +
  scale_x_discrete(expand = c(0, 0)) +
  ggthemes::theme_base() +
  labs(title = 'Subcellular localization') +
  theme(
    plot.background = element_rect(fill = 'white', colour = 'white'),
    plot.title = element_text(hjust = 0.5),
    axis.text.x = element_text(angle = 0),
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_blank(),
    legend.position = "right"
  )

ggsave(file.path(output, '01_rnalocate.pdf'), p, width=8, height=6)
