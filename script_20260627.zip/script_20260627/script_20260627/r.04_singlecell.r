rm(list = ls())
setwd("/data/nas1/liky/project/FX65_KYGW-170308-1-FG/04_singlecell")
ORIGINAL_DIR <- "/data/nas1/liky/project/FX65_KYGW-170308-1-FG/"
output <- file.path(ORIGINAL_DIR, "04_singlecell")

library(Seurat)
library(dplyr)
library(ggplot2)
library(harmony)
library(SingleR)
library(reshape)
library(RColorBrewer)
library(clustree)
library(data.table)
library(patchwork)

data_dir_op <- "/data/nas1/zhangyusheng_OD/project/03_project_job099/04_singlecell/unzip_202603022039_GSE147287_RAW/unzip_202603022032_GSM4423510_MNC_op/2.2.filtered_feature_bc_matrix"  
counts_op <- Read10X(data.dir = data_dir_op)
seu <- CreateSeuratObject(counts = counts_op, project = "GSM4423510")

# ── QC ───────────────────────────────────────────────────────────
seu[["percent.mt"]] <- PercentageFeatureSet(seu, pattern = "^MT-")
seu[["percent.rb"]] <- PercentageFeatureSet(seu, pattern = "^RP[SL]")

p1 <- VlnPlot(seu, 
              features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), 
              ncol = 3, pt.size = 0) +   
  NoLegend() &
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10))
png(file.path(output, "01.violin_plot_before_QC.png"), width=10, height=7, units="in", res=600, family="Times")
print(p1)
dev.off()
pdf(file.path(output, "01.violin_plot_before_QC.pdf"), w=10, h=7, family="Times")
print(p1)
dev.off()

seu <- subset(seu, 
              subset = nFeature_RNA > 200 & nFeature_RNA < 5000 &
                percent.mt < 15 & 
                nCount_RNA < 60000)
cat("After QC:", ncol(seu), "cells,", nrow(seu), "genes\n")
p2 <- VlnPlot(seu, 
              features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), 
              ncol = 3, pt.size = 0) +   
  NoLegend() &
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10))
png(file.path(output, "02.violin_plot_QC.png"), width=10, height=7, units="in", res=600, family="Times")
print(p2)
dev.off()
pdf(file.path(output, "02.violin_plot_QC.pdf"), w=10, h=7, family="Times")
print(p2)
dev.off()









library(Seurat)
library(SingleCellExperiment)
library(scDblFinder)
library(BiocParallel)

# 假设 Seurat 对象名为 seurat_obj

# 1. 查看原始细胞数
seurat_obj <- seu
cat("去除前细胞数：", ncol(seurat_obj), "\n")

# 2. 转换为 SingleCellExperiment 对象
sce <- as.SingleCellExperiment(seurat_obj)

# 3. 按样本识别双细胞
set.seed(123)

sce <- scDblFinder(
  sce,
  BPPARAM = SerialParam(RNGseed = 123)
  # samples = "orig.ident"
)

# 4. 查看双细胞识别结果
print(table(sce$scDblFinder.class))

# 5. 将识别结果添加回 Seurat 对象
seurat_obj$scDblFinder.class <- sce$scDblFinder.class
seurat_obj$scDblFinder.score <- sce$scDblFinder.score

# 6. 统计去除前后的细胞数量
doublet_stat <- table(seurat_obj$scDblFinder.class)
print(doublet_stat)

# 7. 去除双细胞，保留单细胞
seurat_obj <- subset(
  seurat_obj,
  subset = scDblFinder.class == "singlet"
)

cat("去除后细胞数：", ncol(seurat_obj), "\n")

# 8. 保存结果
saveRDS(seurat_obj, file = "seurat_singlets.rds")
seurat_obj <- readRDS("seurat_singlets.rds")

seu <- seurat_obj









# ── 标准化、HVG、PCA ───────────────────────────────────────────
seu <- NormalizeData(seu, normalization.method = "LogNormalize", scale.factor = 10000)
seu <- FindVariableFeatures(seu, selection.method = "vst", nfeatures = 2000)

pdf(file.path(output, "03_hvg_plot.pdf"), width = 8, height = 6)
LabelPoints(plot = VariableFeaturePlot(seu),
            points = head(VariableFeatures(seu), 10), repel = TRUE)
dev.off()
png(file.path(output, "03_hvg_plot.png"), width = 8, height = 6, units = "in", res = 150)
LabelPoints(plot = VariableFeaturePlot(seu),
            points = head(VariableFeatures(seu), 10), repel = TRUE)
dev.off()

seu <- ScaleData(seu)
seu <- RunPCA(seu, features = VariableFeatures(seu))

pdf(file.path(output, "04_elbow_plot.pdf"), width = 7, height = 5)
ElbowPlot(seu, ndims = 50)
dev.off()
png(file.path(output, "04_elbow_plot.png"), width = 7, height = 5, units = "in", res = 150)
ElbowPlot(seu, ndims = 50)
dev.off()
saveRDS(seu, file = "seu1.rds")
seu <- readRDS("seu1.rds")





library(clustree)
seu <- FindNeighbors(seu, reduction = "pca", dims = 1:20)
resolution_seq <- seq(0.1, 1, by = 0.1)
for (res in resolution_seq) {
  seu <- FindClusters(seu, resolution = res, verbose = FALSE)
}

# clustree 图
p_clustree <- clustree(seu, prefix = "RNA_snn_res.")

pdf(file.path(output, "05_clustree.pdf"), width = 12, height = 10)
print(p_clustree)
dev.off()

png(file.path(output, "05_clustree.png"), width = 12, height = 10, units = "in", res = 300)
print(p_clustree)
dev.off()

cluster_summary <- data.frame(
  resolution = resolution_seq,
  n_clusters = sapply(resolution_seq, function(res) {
    col <- paste0("RNA_snn_res.", res)
    length(unique(seu@meta.data[[col]]))
  })
)
print(cluster_summary)

seu <- FindNeighbors(seu, reduction = "pca", dims = 1:20)
seu <- FindClusters(seu, resolution = 0.3)
seu <- RunUMAP(seu, reduction = "pca", dims = 1:20)
seu <- RunTSNE(seu, reduction = "pca", dims = 1:20)
saveRDS(seu, file = "seu2.rds")
seu <- readRDS("seu2.rds")




# UMAP
pdf(file.path(output, "06_umap_clusters.pdf"), width = 6, height = 6)
DimPlot(seu, reduction = "umap", group.by = "seurat_clusters", 
        label = TRUE, repel = TRUE) + NoLegend() + 
  ggtitle("UMAP - Clusters (res=0.3)")
dev.off()
png(file.path(output, "06_umap_clusters.png"), width = 6, height = 6, units = "in", res = 150)
DimPlot(seu, reduction = "umap", group.by = "seurat_clusters", 
        label = TRUE, repel = TRUE) + NoLegend() + 
  ggtitle("UMAP - Clusters (res=0.3)")
dev.off()


pdf(file.path(output, "06_tsne_clusters.pdf"), width = 6, height = 6)
DimPlot(seu, reduction = "tsne", group.by = "seurat_clusters", 
        label = TRUE, repel = TRUE) + NoLegend() + 
  ggtitle("TSNE - Clusters (res=0.3)")
dev.off()
png(file.path(output, "06_tsne_clusters.png"), width = 6, height = 6, units = "in", res = 150)
DimPlot(seu, reduction = "tsne", group.by = "seurat_clusters", 
        label = TRUE, repel = TRUE) + NoLegend() + 
  ggtitle("TSNE - Clusters (res=0.3)")
dev.off()



# ── FindAllMarkers ────────────────────────────────────────────────
seu <- JoinLayers(seu)
all.markers <- FindAllMarkers(seu, 
                              only.pos = TRUE, 
                              min.pct = 0.1, 
                              logfc.threshold = 0.25, 
                              test.use = 'wilcox', 
                              return.thresh = 0.01)
write.table(all.markers, file = file.path(output, "AllMarkers.tsv"), 
            sep = "\t", row.names = FALSE, quote = FALSE)

top10  <- all.markers %>% group_by(cluster) %>% top_n(n = 10,  wt = avg_log2FC)
top30  <- all.markers %>% group_by(cluster) %>% top_n(n = 30,  wt = avg_log2FC)
top50  <- all.markers %>% group_by(cluster) %>% top_n(n = 50,  wt = avg_log2FC)
top100 <- all.markers %>% group_by(cluster) %>% top_n(n = 100, wt = avg_log2FC)
write.table(top10,  file = file.path(output, "top10_markers.tsv"),  sep="\t", row.names=F, quote=F)
write.table(top30,  file = file.path(output, "top30_markers.tsv"),  sep="\t", row.names=F, quote=F)
write.table(top50,  file = file.path(output, "top50_markers.tsv"),  sep="\t", row.names=F, quote=F)
write.table(top100, file = file.path(output, "top100_markers.tsv"), sep="\t", row.names=F, quote=F)

saveRDS(seu, file = file.path(output, "seu_op.rds"))

# ── Marker DotPlot & 细胞注释 ─────────────────────────────────────
seu <- readRDS(file.path(output, "seu_op.rds"))

msc_markers <- list(
  "BM_MSC"       = c("LEPR", "NGFR", "ENG", "THY1", "NT5E", "MCAM"),  
  "Neutrophils"  = c("ITGAM", "FCGR3A", "FCGR3B", "CEACAM8", "S100A8", "S100A9"),  
  "Monocytes"    = c("CD14", "FCGR3A", "CD68", "LYZ"),  
  "B_cells"      = c("CD19", "CD79A", "MS4A1"),  
  "T_cells"      = c("CD3D", "CD3E", "CD3G"),  
  "NK_cells"     = c("NCAM1", "KLRD1", "NKG7", "GNLY"),  
  "Nucleated_RBC"= c("HBA1", "HBB", "HBD") 
  # "Immune"       = c("PTPRC")  
)
unique_markers <- unique(unlist(msc_markers))

pdf(file.path(output, "08_dotplot_markers_by_cluster.pdf"), width = 14, height = 8)
DotPlot(seu, features = unique_markers, group.by = "seurat_clusters") + 
  RotatedAxis() + scale_x_discrete("") + scale_y_discrete("") + 
  ggtitle("Marker Expression by Cluster")
dev.off()
png(file.path(output, "08_dotplot_markers_by_cluster.png"), width = 14, height = 8, units = "in", res = 300)
DotPlot(seu, features = unique_markers, group.by = "seurat_clusters") + 
  RotatedAxis() + scale_x_discrete("") + scale_y_discrete("") + 
  ggtitle("Marker Expression by Cluster")
dev.off()

new_cluster_ids <- c(
  "0"  = "Neutrophils",
  "1"  = "BM_MSC",
  "2"  = "Monocytes",
  "3"  = "Neutrophils",
  "4"  = "Monocytes",
  "5"  = "T_cells",
  "6"  = "Nucleated_RBC", 
  "7"  = "Nucleated_RBC",
  "8"  = "BM_MSC",
  "9"  = "Monocytes",
  "10" = "Neutrophils",
  "11" = "B_cells",
  "12" = "NK_cells",
  "13" = "B_cells",
  "14" = "B_cells"
)


seu <- RenameIdents(seu, new_cluster_ids)
seu$cell.type <- Idents(seu)
table(seu$cell.type)
# Neutrophils        BM_MSC     Monocytes       T_cells Nucleated_RBC       B_cells      NK_cells 
# 2242          1527          1393           339           580           234           115 
pdf(file.path(output, "09_dotplot_markers_by_celltype.pdf"), width = 14, height = 8)
DotPlot(seu, features = unique_markers, group.by = "cell.type") + RotatedAxis() + 
  scale_x_discrete("") + scale_y_discrete("") + 
  ggtitle("Marker Expression by Annotated Cell Type") +
  theme(axis.text.y = element_text(size = 12, face = "bold"))
dev.off()
png(file.path(output, "09_dotplot_markers_by_celltype.png"), width = 14, height = 8, units = "in", res = 300)
DotPlot(seu, features = unique_markers, group.by = "cell.type") + RotatedAxis() + 
  scale_x_discrete("") + scale_y_discrete("") + 
  ggtitle("Marker Expression by Annotated Cell Type") +
  theme(axis.text.y = element_text(size = 12, face = "bold"))
dev.off()

p_ct <- DimPlot(seu, reduction = "umap", group.by = "cell.type",
                shuffle = TRUE, pt.size = 0.6, label = TRUE, label.size = 4) +
  theme_classic() + ggtitle("UMAP by Cell Type (OP)")

pdf(file.path(output, "10_UMAP_celltype_OP.pdf"), width = 8, height = 6)
print(p_ct)
dev.off()
png(file.path(output, "10_UMAP_celltype_OP.png"), width = 8, height = 6, units = "in", res = 600, bg = "white")
print(p_ct)
dev.off()


p_ct <- DimPlot(seu, reduction = "tsne", group.by = "cell.type",
                shuffle = TRUE, pt.size = 0.6, label = TRUE, label.size = 4) +
  theme_classic() + ggtitle("TSNE by Cell Type (OP)")

pdf(file.path(output, "10_TSNE_celltype_OP.pdf"), width = 8, height = 6)
print(p_ct)
dev.off()
png(file.path(output, "10_TSNE_celltype_OP.png"), width = 8, height = 6, units = "in", res = 600, bg = "white")
print(p_ct)
dev.off()





saveRDS(seu, file = file.path(output, "UMAP.rds"))
seu <- readRDS("UMAP.rds")
# ── 细胞比例图（单样本，只展示各细胞类型数量/比例） ──────────────
prop_data <- seu@meta.data %>%
  group_by(cell.type) %>%
  summarise(n_cells = n(), .groups = "drop") %>%
  mutate(total = sum(n_cells),
         proportion = n_cells / total * 100)
print(prop_data)
# cell.type     n_cells total proportion
# <fct>           <int> <int>      <dbl>
#   1 Neutrophils      2242  6430      34.9 
# 2 BM_MSC           1527  6430      23.7 
# 3 Monocytes        1393  6430      21.7 
# 4 T_cells           339  6430       5.27
# 5 Nucleated_RBC     580  6430       9.02
# 6 B_cells           234  6430       3.64
# 7 NK_cells          115  6430       1.79
p_prop <- ggplot(prop_data, aes(x = "", y = proportion, fill = cell.type)) +
  geom_bar(stat = "identity", width = 0.65) +
  scale_fill_brewer(palette = "Set3", name = "Cell Type") +
  labs(x = NULL, y = "Proportion (%)",
       title = "Cell Type Composition (OP sample)") +
  theme_classic(base_size = 13) +
  theme(legend.position = "right",
        plot.title = element_text(hjust = 0.5, face = "bold"))
ggsave(file.path(output, "11_cell_composition_bar_OP.pdf"), p_prop, width = 8, height = 6)
ggsave(file.path(output, "11_cell_composition_bar_OP.png"), p_prop, width = 8, height = 6, dpi = 300)




# ── 细胞比例统计 ──────────────────────────────────────

library(dplyr)

library(ggplot2)

prop_data <- seu@meta.data %>%
  
  group_by(cell.type) %>%
  
  summarise(n_cells = n(), .groups = "drop") %>%
  
  mutate(
    
    total = sum(n_cells),
    
    proportion = n_cells / total * 100,
    
    label = sprintf("%d (%.2f%%)", n_cells, proportion)
    
  ) %>%
  
  arrange(desc(n_cells))

# 按细胞数量降序排列

prop_data$cell.type <- factor(
  
  prop_data$cell.type,
  
  levels = rev(prop_data$cell.type)
  
)

print(prop_data)

# ── 绘制横向排序柱状图 ───────────────────────────────

p_prop <- ggplot(
  
  prop_data,
  
  aes(x = cell.type, y = n_cells, fill = cell.type)
  
) +
  
  geom_col(width = 0.7, show.legend = FALSE) +
  
  geom_text(
    
    aes(label = label),
    
    hjust = -0.1,
    
    size = 4,
    
    color = "black"
    
  ) +
  
  coord_flip() +
  
  scale_fill_brewer(palette = "Set3") +
  
  scale_y_continuous(
    
    expand = expansion(mult = c(0, 0.25))
    
  ) +
  
  labs(
    
    x = NULL,
    
    y = "Number of Cells",
    
    title = "Cell Type Composition (OP Sample)"
    
  ) +
  
  theme_classic(base_size = 13) +
  
  theme(
    
    plot.title = element_text(
      
      hjust = 0.5,
      
      face = "bold",
      
      size = 14
      
    ),
    
    axis.text = element_text(color = "black"),
    
    axis.title.x = element_text(margin = margin(t = 10)),
    
    axis.title.y = element_blank()
    
  )

# ── 保存图片 ──────────────────────────────────────────

ggsave(
  
  file.path(output, "11_cell_composition_bar_OP-2.pdf"),
  
  p_prop,
  
  width = 9,
  
  height = 6
  
)

ggsave(
  
  file.path(output, "11_cell_composition_bar_OP-2.png"),
  
  p_prop,
  
  width = 9,
  
  height = 6,
  
  dpi = 300
  
)





library(tidyr)
library(ggpubr)

key_genes <- read.csv('/data/nas1/zhangyusheng_OD/project/03_project_job099/03_machine/keygene.csv')$symbol

expr_data <- FetchData(seu, 
                       vars = c(key_genes, "cell.type"),
                       slot = "data") %>%
  as_tibble(rownames = NA) %>%
  pivot_longer(cols = all_of(key_genes),
               names_to = "Gene",
               values_to = "Expression")

p <- ggplot(expr_data, aes(x = cell.type, y = Expression, fill = cell.type)) +
  geom_violin(trim = FALSE, alpha = 0.5, width = 0.8) +
  geom_boxplot(width = 0.18, outlier.shape = NA, alpha = 0.9) +
  facet_wrap(~ Gene, scales = "free_y") +
  scale_fill_brewer(palette = "Set2") +
  labs(x = NULL, y = "Normalized Expression",
       title = "Key Gene Expression across Cell Types (OP)") +
  theme_bw(base_size = 12) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 9),
        strip.text = element_text(size = 11, face = "bold"),
        legend.position = "none")
ggsave(file.path(output, "12_key_genes_expression_by_celltype.pdf"), p, width = 14, height = 8)
ggsave(file.path(output, "12_key_genes_expression_by_celltype.png"), p, width = 14, height = 8, dpi = 300)

# ── Module Score ──────────────────────────────────────────────────
key_genes_list <- list(read.csv('/data/nas1/zhangyusheng_OD/project/03_project_job099/03_machine/keygene.csv')$symbol)
seu <- AddModuleScore(seu, features = key_genes_list, name = "Module_Score")

module_col <- grep("Module_Score", colnames(seu@meta.data), value = TRUE)[1]

expr_data2 <- FetchData(seu, vars = c(module_col, "cell.type"), slot = "data") %>%
  as_tibble(rownames = NA) %>%
  dplyr::rename(Module_Score = all_of(module_col))

p_score <- ggplot(expr_data2, aes(x = cell.type, y = Module_Score, fill = cell.type)) +
  geom_violin(trim = FALSE, alpha = 0.5, width = 0.8) +
  geom_boxplot(width = 0.18, outlier.shape = NA, alpha = 0.9) +
  scale_fill_brewer(palette = "Set2") +
  labs(x = NULL, y = "Module Score", title = "Module Score across Cell Types (OP)") +
  theme_bw(base_size = 12) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
        strip.background = element_rect(fill = "grey90"),
        legend.position = "none")
ggsave(file.path(output, "13_combined_module_score_by_celltype.pdf"), p_score, width = 12, height = 6)
ggsave(file.path(output, "13_combined_module_score_by_celltype.png"), p_score, width = 12, height = 6, dpi = 300)
mean_expr <- expr_data %>%
  group_by(Gene, cell.type) %>%
  summarise(
    mean_expr   = mean(Expression),
    median_expr = median(Expression),
    pct_expr    = mean(Expression > 0) * 100,   
    .groups = "drop"
  ) %>%
  arrange(Gene, desc(mean_expr))

print(mean_expr)
write.csv(mean_expr, file.path(output, "12_mean_expression_ranked.csv"), row.names = FALSE)
p_dot <- DotPlot(seu,
                 features  = key_genes,
                 group.by  = "cell.type",
                 dot.scale = 10,
                 cols      = c("lightgrey", "#E64B35")) +
  RotatedAxis() +
  labs(title = "Key Gene Expression across Cell Types (OP)") +
  theme_bw(base_size = 12) +
  theme(
    plot.title  = element_text(hjust = 0.5, face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.text.x = element_text(face = "bold.italic", size = 11)
  )

ggsave(file.path(output, "14_dotplot_key_genes.pdf"), p_dot, width = 10, height = 5)
ggsave(file.path(output, "14_dotplot_key_genes.png"), p_dot, width = 10, height = 5, dpi = 300)
print(mean_expr, n = Inf)

library(ggsignif)
library(rstatix)
for (g in key_genes) {
  
  df_g <- expr_data %>% filter(Gene == g)
  
  kw <- kruskal_test(df_g, Expression ~ cell.type)
  kw_p <- signif(kw$p, 3)
  
  sig_pairs    <- list()
  sig_labels   <- c()
  
  if (kw$p < 0.05) {
    dunn_g <- df_g %>%
      dunn_test(Expression ~ cell.type, p.adjust.method = "BH") %>%
      add_significance("p.adj") %>%
      filter(p.adj < 0.05)
    
    if (nrow(dunn_g) > 0) {
      sig_pairs  <- lapply(1:nrow(dunn_g), function(i) c(dunn_g$group1[i], dunn_g$group2[i]))
      sig_labels <- dunn_g$p.adj.signif
    }
  }
  
  p_g <- ggplot(df_g, aes(x = cell.type, y = Expression, fill = cell.type)) +
    geom_violin(trim = FALSE, alpha = 0.45, width = 0.85) +
    geom_boxplot(width = 0.18, outlier.shape = NA, alpha = 0.9) +
    scale_fill_brewer(palette = "Set2") +
    labs(
      x        = NULL,
      y        = "Normalized Expression",
      title    = paste0(g, " Expression across Cell Types (OP)"),
      subtitle = paste0("Kruskal-Wallis p = ", kw_p)
    ) +
    theme_bw(base_size = 13) +
    theme(
      axis.text.x     = element_text(angle = 45, hjust = 1, size = 10),
      plot.title      = element_text(hjust = 0.5, face = "bold.italic"),
      plot.subtitle   = element_text(hjust = 0.5, color = "grey40"),
      legend.position = "none"
    )
  
  if (length(sig_pairs) > 0) {
    p_g <- p_g + geom_signif(
      comparisons  = sig_pairs,
      annotations  = sig_labels,
      step_increase = 0.1,
      tip_length   = 0.01,
      textsize     = 4
    )
  }
  
  ggsave(file.path(output, paste0("15_violin_", g, ".pdf")), p_g, width = 8, height = 6)
  ggsave(file.path(output, paste0("15_violin_", g, ".png")), p_g, width = 8, height = 6, dpi = 300)
}
# ── 亚群分析（GSVA）────────────────────────────────────
library(GSVA)
library(msigdbr)
library(pheatmap)
library(tibble)

seu_mono <- subset(seu, subset = cell.type == "Monocytes")
seu_mono <- NormalizeData(seu_mono)
seu_mono <- FindVariableFeatures(seu_mono)
seu_mono <- ScaleData(seu_mono)
seu_mono <- RunPCA(seu_mono)
seu_mono <- FindNeighbors(seu_mono, dims = 1:20)
seu_mono <- FindClusters(seu_mono, resolution = 0.4)
seu_mono <- RunUMAP(seu_mono, dims = 1:20)
saveRDS(seu_mono, file = file.path(output, "seu_mono.rds"))
seu_mono <- readRDS('seu_mono.rds')
p1 <- DimPlot(seu_mono, group.by = "seurat_clusters", label = TRUE)
ggsave(file.path(output, "16_DimPlot_mono_clusters.pdf"), p1, width = 8, height = 6)
ggsave(file.path(output, "16_DimPlot_mono_clusters.png"), p1, width = 8, height = 6, dpi = 300)

table(seu_mono$seurat_clusters)

# GSVA by cluster
reactome_gs   <- msigdbr(species = "Homo sapiens", category = "C2", subcategory = "CP:REACTOME")
reactome_list <- split(reactome_gs$gene_symbol, reactome_gs$gs_name)

pseudo_bulk_mat <- as.matrix(AggregateExpression(seu_mono,
                                                 group.by = "seurat_clusters",
                                                 assays = "RNA",
                                                 slot = "data")$RNA)
colnames(pseudo_bulk_mat) <- paste0("Cluster ", gsub("^g", "", colnames(pseudo_bulk_mat)))
gsva_res <- gsva(pseudo_bulk_mat, reactome_list,
                 method = "gsva", kcdf = "Gaussian", mx.diff = TRUE)

pathway_var  <- apply(gsva_res, 1, var)
top_pathways <- names(sort(pathway_var, decreasing = TRUE)[1:20])

p_heatmap <- pheatmap(gsva_res[top_pathways, ],
                      cluster_rows = TRUE, cluster_cols = TRUE,
                      main = "Top 20 Variable Reactome Pathways in Monocytes Subclusters (OP)",
                      color = colorRampPalette(c("navy", "white", "firebrick3"))(20),
                      fontsize = 8, fontsize_row = 8, fontsize_col = 10,
                      cellwidth = 20, cellheight = 12,
                      border_color = NA)
ggsave(file.path(output, "17_reactome_top20_heatmap.pdf"),  p_heatmap, width = 12, height = 6)
ggsave(file.path(output, "17_reactome_top20_heatmap.png"),  p_heatmap, width = 12, height = 6, dpi = 300)

write.csv(gsva_res, file.path(output, "gsva_reactome_scores_Monocytes.csv"))
