rm(list = ls())
setwd('')
ORIGINAL_DIR <- ""
output <- file.path(ORIGINAL_DIR, "14_cor")

library(tidyverse)
library(corrplot)

hubgene <- data.frame(gene = read.csv('')$symbol)
train_data <- read.csv("", header=TRUE, row.names=1, check.names=FALSE)
group <- read.csv("")

train_data <- train_data[, group$sample]
hubgene_exp <- train_data[hubgene$gene, ] %>% t() %>% as.data.frame()

testRes <- cor.mtest(hubgene_exp, method="spearman", conf.level=0.95)
r <- cor(hubgene_exp, method="spearman")

write.csv(r, file.path(output, "OP_cor_result.csv"), quote=FALSE)
write.csv(testRes$p, file.path(output, "OP_Pvalue_result.csv"), quote=FALSE)

col <- colorRampPalette(c("#1874CD", "white", "#FED82F"), alpha=TRUE)

pdf(width=6, height=6, file=file.path(output, "OP_corrplot.pdf"), bg="white")
par(pin=c(4,4), mar=c(6,6,6,5), family="Times", font=2, cex.axis=4)
corrplot(r, method="color", col=col(100),
         tl.col="black", tl.cex=1.5, tl.srt=45, tl.pos="lt",
         p.mat=testRes$p, diag=TRUE, type="upper",
         sig.level=c(0.001, 0.01, 0.05), pch.cex=1.5,
         insig="label_sig", pch.col="grey20", order="AOE")
corrplot(r, method="pie", type="lower", col=col(100),
         tl.col="n", tl.cex=1.5, tl.pos="n", order="AOE", add=TRUE)
dev.off()

png(width=6, height=6, units="in", res=600, file=file.path(output, "OP_corrplot.png"), bg="white")
par(pin=c(4,4), mar=c(6,6,6,5), family="Times", font=2, cex.axis=4)
corrplot(r, method="color", col=col(100),
         tl.col="black", tl.cex=1.5, tl.srt=45, tl.pos="lt",
         p.mat=testRes$p, diag=TRUE, type="upper",
         sig.level=c(0.001, 0.01, 0.05), pch.cex=1.5,
         insig="label_sig", pch.col="grey20", order="AOE")
corrplot(r, method="pie", type="lower", col=col(100),
         tl.col="n", tl.cex=1.5, tl.pos="n", order="AOE", add=TRUE)
dev.off()

library(GOSemSim)
library(clusterProfiler)
library(org.Hs.eg.db)
library(reshape2)
library(ggplot2)

Genes <- data.frame(
  SYMBOL = c("NDUFB5", "SRC"),
  ENTREZID = c("4708", "6714"),
  stringsAsFactors = FALSE
)

bp <- godata("org.Hs.eg.db", ont="BP", computeIC=FALSE)
cc <- godata("org.Hs.eg.db", ont="CC", computeIC=FALSE)
mf <- godata("org.Hs.eg.db", ont="MF", computeIC=FALSE)

simbp <- mgeneSim(Genes$ENTREZID, semData=bp, measure="Wang", drop=NULL, combine="BMA")
simcc <- mgeneSim(Genes$ENTREZID, semData=cc, measure="Wang", drop=NULL, combine="BMA")
simmf <- mgeneSim(Genes$ENTREZID, semData=mf, measure="Wang", drop=NULL, combine="BMA")

gene_order <- c("NDUFB5", "SRC")
simbp <- simbp[Genes$ENTREZID, Genes$ENTREZID]
simcc <- simcc[Genes$ENTREZID, Genes$ENTREZID]
simmf <- simmf[Genes$ENTREZID, Genes$ENTREZID]

colnames(simbp) <- gene_order; rownames(simbp) <- gene_order
colnames(simcc) <- gene_order; rownames(simcc) <- gene_order
colnames(simmf) <- gene_order; rownames(simmf) <- gene_order

fsim <- (simbp * simcc * simmf)^(1/3)
for(i in 1:ncol(fsim)) { fsim[i,i] <- NA }

write.csv(fsim, file.path(output, "NDUFB5_SRC_Similarity.csv"), row.names=TRUE, quote=FALSE)

dat <- reshape2::melt(fsim)
dat <- dat[!is.na(dat$value), ]
dat <- dat[, c(1,3)]
colnames(dat) <- c("Var1", "value")

dat.mean <- aggregate(value ~ Var1, dat, mean)
m <- dat.mean$value
names(m) <- dat.mean$Var1
dat$Var1 <- factor(dat$Var1, levels=names(sort(m)))

p <- ggplot(dat, aes(x=Var1, y=value, fill=factor(Var1))) +
  scale_fill_brewer(palette="Set2") +
  geom_boxplot(alpha=0.8) +
  coord_flip() +
  xlab("Genes") +
  ylab("Functional Similarity Score") +
  theme_bw() +
  theme(
    legend.position="none",
    axis.text=element_text(size=12),
    axis.title=element_text(size=14, face="bold")
  )

ggsave(file.path(output, "NDUFB5_SRC_Similarity_Box.pdf"), plot=p, width=8, height=6)
ggsave(file.path(output, "NDUFB5_SRC_Similarity_Box.png"), plot=p, width=8, height=6, units="in", dpi=300, bg="white")

r_matrix <- read.csv(file.path(output, "OP_cor_result.csv"), row.names=1, check.names=FALSE)
p_matrix <- read.csv(file.path(output, "OP_Pvalue_result.csv"), row.names=1, check.names=FALSE)
genes <- rownames(r_matrix)

cor_table <- expand.grid(Gene1=genes, Gene2=genes) %>%
  filter(match(Gene1, genes) < match(Gene2, genes)) %>%
  mutate(
    Spearman_r=round(sapply(1:nrow(.), function(x) r_matrix[.$Gene1[x], .$Gene2[x]]), 3),
    P_value=round(sapply(1:nrow(.), function(x) p_matrix[.$Gene1[x], .$Gene2[x]]), 6),
    Significance=case_when(
      P_value < 0.001 ~ "***",
      P_value < 0.01  ~ "**",
      P_value < 0.05  ~ "*",
      TRUE ~ "ns"
    )
  )

sim_matrix <- read.csv(file.path(output, "NDUFB5_SRC_Similarity.csv"), row.names=1, check.names=FALSE)
sim_table <- as.data.frame(sim_matrix) %>%
  rownames_to_column("Gene") %>%
  mutate(Mean_similarity=round(rowMeans(.[,-1], na.rm=TRUE), 3)) %>%
  dplyr::select(Gene, everything())

print(cor_table, row.names=FALSE)
print(sim_table, row.names=FALSE)

write.csv(cor_table, file.path(output, "OP_cor_table.csv"), row.names=FALSE, quote=FALSE)
write.csv(sim_table, file.path(output, "OP_similarity_table.csv"), row.names=FALSE, quote=FALSE)

